/**
 * ============================================================================
 *  EAC — SERVICES.JS — Rendu de la page Services (services.html)
 * ============================================================================
 */
(function () {
  "use strict";
  const C = window.EAC_COMMON;
  const esc = C.esc, $ = C.$, el = C.el, safeImg = C.safeImg;
  const content = C.content;

  function getContentFor(lang) {
    return window.EAC_TRANSLATE ? window.EAC_TRANSLATE(content, lang) : content;
  }

  function renderTeamMini() {
    const container = $("#team-mini-container");
    if (!container) return;
    const members = [
      { name: "Xavier", role: "Webmaster", img: "assets/img/team/xavier-aurelien.jpg" },
      { name: "Benoît", role: "Finance", img: "assets/img/team/zogo-benoit.jpg" },
      { name: "Edith", role: "Marketing", img: "assets/img/team/edith-kouekam.jpg" }
    ];
    container.innerHTML = "";
    members.forEach((m) => {
      const card = el("div", { class: "team-mini-card" });
      const img = el("img", { src: safeImg(m.img), alt: esc(m.name), loading: "lazy" });
      img.onerror = function () { this.src = "assets/img/logo.png"; };
      card.appendChild(img);
      card.appendChild(el("h3", {}, esc(m.name)));
      card.appendChild(el("p", { class: "role" }, esc(m.role)));
      const social = el("div", { class: "res-p" });
      social.appendChild(C.socialIcons((content.site || {}).social));
      card.appendChild(social);
      container.appendChild(card);
    });
  }

  function renderServices(lang) {
    const c = getContentFor(lang);
    const container = $("#services-container");
    if (!container) return;
    container.innerHTML = "";
    (c.services || []).forEach((s) => {
      const card = el("div", { class: "service-card" });
      card.innerHTML = `
        <i class="fas ${esc(s.icon || "fa-star")}" aria-hidden="true"></i>
        <h3>${esc(s.title)}</h3>
        <p>${esc(s.desc)}</p>
        <a href="contact.html" target="_blank" rel="noopener" class="btn btn-primary">En savoir plus</a>`;
      container.appendChild(card);
    });
  }

  function renderPrices(lang) {
    const c = getContentFor(lang);
    const dict = (window.EAC_I18N && window.EAC_I18N[lang]) || (window.EAC_I18N && window.EAC_I18N.fr) || {};
    const btnLabel = dict.reserve || "À venir";
    const container = $("#prices-container");
    if (!container) return;
    container.innerHTML = "";
    (c.prices || []).forEach((p) => {
      const card = el("div", { class: "price-card" + (p.featured ? " featured" : "") });
      const items = (p.items || []).map((it) => `<li>${esc(it)}</li>`).join("");
      card.innerHTML = `
        <h3>${esc(p.name)}</h3>
        <div class="price">${esc(p.price)} <span>${esc(p.period || "")}</span></div>
        <ul>${items}</ul>
        <button class="btn btn-primary" type="button">${esc(btnLabel)}</button>`;
      card.querySelector("button").addEventListener("click", () => {
        C.pushRecord("eac_bookings", { plan: p.name, price: p.price });
        C.toast(`Merci pour votre intérêt pour l'offre "${p.name}" ! Cette fonctionnalité arrive bientôt — nous vous recontacterons.`);
      });
      container.appendChild(card);
    });
  }

  function renderCreations() {
    const container = $("#creations-container");
    if (!container) return;
    const items = [
      { title: "Initiation au Web", desc: "Découvrez les bases du développement web.", img: "assets/img/logo.png" },
      { title: "Création de jeux analogiques", desc: "Concevez vos propres jeux de plateau.", img: "assets/img/games/busara.jpg" },
      { title: "Création de jeux vidéo 2D/3D", desc: "Du concept au prototype jouable.", img: "assets/img/team/aurion-artwork.jpg" },
      { title: "Ateliers numériques / prise en main", desc: "Formations pratiques aux outils numériques.", img: "assets/img/bonus/ongola-land-alt-cover.png" },
      { title: "Gamification des entreprises", desc: "Boostez l'engagement grâce au jeu.", img: "assets/img/games/collection-eac.jpg" }
    ];
    container.innerHTML = "";
    items.forEach((it) => {
      const card = el("div", { class: "creation-item" });
      const img = el("img", { src: safeImg(it.img), alt: esc(it.title), loading: "lazy" });
      img.onerror = function () { this.src = "assets/img/logo.png"; };
      card.appendChild(img);
      const textWrap = el("div");
      textWrap.appendChild(el("h4", {}, esc(it.title)));
      textWrap.appendChild(el("p", {}, esc(it.desc)));
      card.appendChild(textWrap);
      container.appendChild(card);
    });
  }

  function renderPartnersRow() {
    const container = $("#partners-row-container");
    if (!container) return;
    const logos = [
      { src: "assets/img/partners/goethe-institut.png", alt: "Goethe-Institut" },
      { src: "assets/img/partners/spielfabrique.png", alt: "SpielFabrique" },
      { src: "assets/img/partners/enspy.png", alt: "ENSPY" },
      { src: "assets/img/partners/metheore-consulting.jpg", alt: "Metheore Consulting" },
      { src: "assets/img/logo.png", alt: "Enter Africa Cameroun" }
    ];
    container.innerHTML = "";
    logos.forEach((l) => {
      const img = el("img", { src: safeImg(l.src), alt: esc(l.alt), loading: "lazy" });
      img.onerror = function () { this.style.display = "none"; };
      container.appendChild(img);
    });
  }

  function renderFAQ(lang) {
    const c = getContentFor(lang);
    const container = $("#faq-container");
    if (!container) return;
    container.innerHTML = "";
    (c.faq || []).forEach((f, i) => {
      const details = el("details", { class: "faq-item" });
      if (i === 0) details.open = true;
      details.innerHTML = `
        <summary>${esc(f.q)} <span class="chevron">&#8250;</span></summary>
        <div class="content"><p>${esc(f.a)}</p></div>`;
      container.appendChild(details);
    });
  }

  function renderResources() {
    const container = $("#resources-container");
    if (!container) return;
    container.innerHTML = "";
    (content.externalResources || []).forEach((r) => {
      if (!window.EAC_STORAGE.isSafeUrl(r.url)) return;
      const card = el("a", { href: r.url, class: "resource-card", target: "_blank", rel: "noopener noreferrer" });
      card.innerHTML = `
        <div class="resource-card-icon"><i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i></div>
        <h4>${esc(r.name)}</h4>
        <p>${esc(r.desc || "")}</p>`;
      container.appendChild(card);
    });
  }

  function renderAll(lang) {
    renderServices(lang);
    renderPrices(lang);
    renderFAQ(lang);
  }

  function init() {
    const savedLang = C.initCommon();
    renderTeamMini();
    renderCreations();
    renderPartnersRow();
    renderResources();
    renderAll(savedLang);
    C.onLanguageChange(renderAll);
    C.initScrollAnimations();
    C.applyLanguage(savedLang);
    C.playIntroTypewriter("#services-page-title");
    console.log("EAC — page Services chargée.");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
