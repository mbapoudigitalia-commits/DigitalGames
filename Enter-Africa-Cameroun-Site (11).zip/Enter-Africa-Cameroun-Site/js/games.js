/**
 * ============================================================================
 *  EAC — GAMES.JS — Rendu de la page Jeux (games.html)
 * ============================================================================
 */
(function () {
  "use strict";
  const C = window.EAC_COMMON;
  const esc = C.esc, $ = C.$, el = C.el, safeImg = C.safeImg;
  const content = C.content;

  function getContentFor(lang) {
    return window.EAC_TRANSLATE ? window.EAC_TRANSLATE(content, lang) : content;
  }

  function renderHeroVideo() {
    const wrap = $("#games-hero-video-wrap");
    if (!wrap) return;
    const g = content.genese || {};
    if (g.video && g.video.youtubeId) {
      wrap.innerHTML = "";
      wrap.appendChild(C.buildYoutubeEmbed(g.video.youtubeId, g.video.poster, "Lancement du jeu Ongola Land"));
    }
  }

  function renderActivities() {
    const container = $("#activities-container");
    if (!container) return;
    const items = [
      { img: "assets/img/games/ongola-land.jpg", label: "Ongola Land" },
      { img: "assets/img/games/busara.jpg", label: "Busara Strategy" },
      { img: "assets/img/games/voyageur.png", label: "Voyageur" }
    ];
    container.innerHTML = "";
    items.forEach((it) => {
      const card = el("div", { class: "activity-card" });
      const img = el("img", { src: safeImg(it.img), alt: esc(it.label), loading: "lazy" });
      img.onerror = function () { this.src = "assets/img/logo.png"; };
      card.appendChild(img);
      card.appendChild(el("p", {}, esc(it.label)));
      container.appendChild(card);
    });
  }

  function renderGamesCarousel(lang) {
    const c = getContentFor(lang);
    const container = $("#games-carousel-container");
    if (!container) return;
    container.innerHTML = "";
    (c.games || []).forEach((g) => {
      const card = el("div", { class: "carousel-card" });
      const img = el("img", { src: safeImg(g.img), alt: esc(g.title), loading: "lazy" });
      img.onerror = function () { this.src = "assets/img/logo.png"; };
      card.appendChild(img);
      const contentDiv = el("div", { class: "carousel-card-content" });
      contentDiv.appendChild(el("h3", {}, esc(g.title)));
      contentDiv.appendChild(el("p", {}, esc(g.desc)));
      if (g.link && g.link.trim() !== "" && window.EAC_STORAGE.isSafeUrl(g.link)) {
        const isPlayable = /assets\/games\//.test(g.link);
        const a = el("a", { href: g.link, class: "btn btn-primary", target: "_blank", rel: "noopener noreferrer" }, isPlayable ? "▶ Jouer" : "Découvrir");
        contentDiv.appendChild(a);
      }
      card.appendChild(contentDiv);
      container.appendChild(card);
    });
  }

  function renderVideos() {
    const container = $("#videos-container");
    if (!container) return;
    container.innerHTML = "";
    (content.videos || []).forEach((v) => {
      const card = el("div", { class: "video-card" });
      card.appendChild(C.buildYoutubeEmbed(v.youtubeId, `https://i.ytimg.com/vi/${v.youtubeId}/hqdefault.jpg`, v.title));
      const meta = el("div", { class: "video-card-meta" });
      meta.appendChild(el("h4", {}, esc(v.title)));
      meta.appendChild(el("p", {}, esc(v.channel || "Enter Africa Cameroun")));
      card.appendChild(meta);
      container.appendChild(card);
    });
  }

  function renderCapture(lang) {
    const c = getContentFor(lang);
    const cap = c.capture || {};
    const t = $("#capture-title"); if (t) t.textContent = cap.title || "";
    const d = $("#capture-desc"); if (d) d.textContent = cap.desc || "";
    const img = $("#capture-image");
    if (img) { img.src = safeImg(cap.pdfPreview); img.onerror = function () { this.src = "assets/img/logo.png"; }; }
  }

  function renderAll(lang) {
    renderGamesCarousel(lang);
    renderCapture(lang);
  }

  function initCaptureForm() {
    const form = $("#captureForm");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const email = $("#captureEmail").value.trim();
      if (!email) return;
      C.pushRecord("eac_leads", { email: email });
      $("#captureMessage").innerHTML = "✅ Merci ! Téléchargement en cours…";
      const rawPdf = (content.capture && content.capture.pdfFile) || "assets/docs/checklist-avant-publication-site-web.pdf";
      const pdf = window.EAC_STORAGE.isSafeUrl(rawPdf) ? rawPdf : "assets/docs/checklist-avant-publication-site-web.pdf";
      setTimeout(() => {
        window.open(pdf, "_blank", "noopener,noreferrer");
        $("#captureMessage").innerHTML = "📄 Téléchargement lancé ! Vérifiez vos téléchargements.";
      }, 600);
      this.reset();
    });
  }

  function init() {
    const savedLang = C.initCommon();
    renderHeroVideo();
    renderActivities();
    renderVideos();
    renderAll(savedLang);
    C.onLanguageChange(renderAll);
    C.initScrollAnimations();
    initCaptureForm();
    C.applyLanguage(savedLang);
    C.playIntroTypewriter("#games-page-title");
    console.log("EAC — page Jeux chargée.");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
