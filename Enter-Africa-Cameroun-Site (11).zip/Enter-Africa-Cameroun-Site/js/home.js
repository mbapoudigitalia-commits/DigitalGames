/**
 * ============================================================================
 *  EAC — HOME.JS — Rendu de la page d'accueil (index.html)
 * ============================================================================
 */
(function () {
  "use strict";
  const C = window.EAC_COMMON;
  const esc = C.esc, $ = C.$, el = C.el, isExternal = C.isExternal, safeImg = C.safeImg;
  const content = C.content;

  function getContentFor(lang) {
    return window.EAC_TRANSLATE ? window.EAC_TRANSLATE(content, lang) : content;
  }

  /* ============================ GALERIE ============================ */
  function renderGallery(lang) {
    const c = getContentFor(lang);
    const container = $("#gallery-container");
    if (!container) return;
    container.innerHTML = "";
    (c.gallery || []).forEach((item) => {
      const card = el("div", { class: "gallery-card" });
      const media = el("div", { class: "gallery-card-media" });
      const img = el("img", { src: safeImg(item.img), alt: esc(item.title), loading: "lazy" });
      img.onerror = function () { this.src = "assets/img/logo.png"; };
      media.appendChild(img);
      card.appendChild(media);

      const captionHref = item.videoUrl || item.link;
      if (item.videoUrl && window.EAC_STORAGE.isSafeUrl(item.videoUrl)) {
        // Vidéo : ouverture dans la modal du site, sans navigation externe
        const btn = el("button", { type: "button", class: "gallery-card-caption gallery-caption-video" });
        btn.innerHTML = '<i class="fas fa-circle-play play-hint" aria-hidden="true"></i>' + esc(item.title);
        btn.addEventListener("click", () => C.openVideoModal(C.extractYoutubeId(item.videoUrl), item.title));
        card.appendChild(btn);
      } else if (item.link && window.EAC_STORAGE.isSafeUrl(item.link)) {
        const a = el("a", { href: item.link, class: "gallery-card-caption" });
        const opensNewTab = isExternal(item.link) || /^(games|services|contact)\.html/.test(item.link);
        if (opensNewTab) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener noreferrer"); }
        a.textContent = item.title;
        card.appendChild(a);
      } else {
        card.appendChild(el("span", { class: "gallery-card-caption" }, esc(item.title)));
      }
      container.appendChild(card);
    });
  }

  /* ============================ MOMENTS (carousel) ============================ */
  function renderMoments(lang) {
    const c = getContentFor(lang);
    const container = $("#moments-container");
    if (!container) return;
    container.innerHTML = "";
    (c.slider || []).forEach((item, i) => {
      const id = "moment" + (i + 1);
      const input = el("input", { type: "radio", name: "slide", id: id });
      if (i === 0) input.checked = true;
      const label = el("label", { for: id, class: "card" });
      label.style.backgroundImage = `url('${safeImg(item.img)}')`;
      label.innerHTML = `
        <div class="row">
          <div class="icon">${esc(item.icon)}</div>
          <div class="description">
            <h4>${item.titleHtml}</h4>
            <p>${esc(item.desc)}</p>
          </div>
        </div>`;
      container.appendChild(input);
      container.appendChild(label);
    });
  }

  /* ============================ VISION 2030 ============================ */
  function renderVision(lang) {
    const c = getContentFor(lang);
    const v = c.vision2030 || {};
    const titleEl = $("#vision2030-title"); if (titleEl) titleEl.innerHTML = v.titleHtml || "";
    const t1 = $("#vision-text1"); if (t1) t1.innerHTML = v.visionHtml || "";
    const t2 = $("#vision-text2"); if (t2) t2.innerHTML = v.visionHtml2 || "";
    const cta = $("#vision-cta"); if (cta) cta.textContent = v.ctaText || "EAC-2030";

    const processList = $("#process-list");
    if (processList) {
      processList.innerHTML = "";
      (v.process || []).forEach((p) => processList.appendChild(el("a", { href: "services.html", target: "_blank", rel: "noopener" }, p)));
    }
    const partnersList = $("#partners-list");
    if (partnersList) {
      partnersList.innerHTML = "";
      (v.partners || []).forEach((p) => {
        const wrap = el("p");
        wrap.appendChild(el("a", { href: "contact.html", target: "_blank", rel: "noopener" }, esc(p)));
        partnersList.appendChild(wrap);
      });
    }
  }

  /* ============================ GENESE + TEAM ============================ */
  function renderGeneseAndTeam(lang) {
    const c = getContentFor(lang);
    const g = c.genese || {};
    const geneseTitle = $("#genese-title-text"); if (geneseTitle) geneseTitle.textContent = g.title || "";
    const geneseText = $("#genese-text"); if (geneseText) geneseText.innerHTML = g.html || "";

    const videoWrap = $("#genese-video-wrap");
    if (g.video && g.video.youtubeId && videoWrap) {
      videoWrap.innerHTML = "";
      videoWrap.appendChild(C.buildYoutubeEmbed(g.video.youtubeId, g.video.poster, g.video.alt));
    }
    const presTitle = $("#presentation-title"); if (presTitle) presTitle.innerHTML = c.presentationTitleHtml || "";

    const t = c.team || {};
    const teamTitle = $("#team-title"); if (teamTitle) teamTitle.textContent = t.title || "";
    const teamImg = $("#team-img");
    if (teamImg) { teamImg.src = safeImg(t.img); teamImg.onerror = function () { this.src = "assets/img/logo.png"; }; }
  }

  function renderAll(lang) {
    renderGeneseAndTeam(lang);
    renderGallery(lang);
    renderMoments(lang);
    renderVision(lang);
  }

  /* ============================ FORMULAIRE DE RENDEZ-VOUS ============================ */
  function initForms() {
    const form = $("#meetingForm");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const data = new FormData(this);
      const record = { name: data.get("name"), phone: data.get("phone"), email: data.get("email"), org: !!data.get("function"), message: data.get("message") };
      if (!record.name || !record.email) { $("#meetingStatus").textContent = "Merci de renseigner votre nom et votre email."; return; }
      C.pushRecord("eac_meetings", record);
      $("#meetingStatus").textContent = "✅ Demande envoyée ! Nous vous recontactons rapidement.";
      C.toast("Votre demande de rendez-vous a été enregistrée.");
      this.reset();
    });
  }

  /* ============================ INIT ============================ */
  function init() {
    const savedLang = C.initCommon();
    renderAll(savedLang);
    C.onLanguageChange(renderAll);
    C.initScrollAnimations();
    initForms();
    C.applyLanguage(savedLang);

    // Effet machine à écrire d'ouverture (menu, titre, texte de bienvenue,
    // lien ICI) — ne se rejoue pas au changement de langue.
    C.playIntroTypewriter("#home-title");

    console.log("EAC — page Accueil chargée.");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
