/**
 * ============================================================================
 *  EAC — CONTACT.JS — Rendu de la page Contact (contact.html)
 * ============================================================================
 */
(function () {
  "use strict";
  const C = window.EAC_COMMON;
  const $ = C.$;
  const content = C.content;

  function renderContactInfo() {
    const site = content.site || {};
    const addr = $("#contact-address"); if (addr) addr.textContent = site.address || "";
    const phone = $("#contact-phone"); if (phone) phone.textContent = site.phone || "";
    const email = $("#contact-email"); if (email) email.textContent = site.email || "";
    const hours = $("#contact-hours"); if (hours) hours.textContent = site.hours || "";
    const socials = $("#contact-socials"); if (socials) socials.appendChild(C.socialIcons(site.social));
  }

  function initContactForm() {
    const form = $("#contactForm");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const record = {
        name: $("#cf-name").value,
        email: $("#cf-email").value,
        subject: $("#cf-subject").value,
        message: $("#cf-message").value
      };
      if (!record.name || !record.email || !record.message) {
        $("#contactStatus").textContent = "Merci de compléter les champs obligatoires.";
        return;
      }
      C.pushRecord("eac_messages", record);
      $("#contactStatus").textContent = "✅ Message envoyé avec succès !";
      C.toast("Votre message a été envoyé.");
      this.reset();
    });
  }

  function init() {
    const savedLang = C.initCommon();
    renderContactInfo();
    C.initScrollAnimations();
    initContactForm();
    C.applyLanguage(savedLang);
    C.playIntroTypewriter("#contact-page-title");
    console.log("EAC — page Contact chargée.");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
