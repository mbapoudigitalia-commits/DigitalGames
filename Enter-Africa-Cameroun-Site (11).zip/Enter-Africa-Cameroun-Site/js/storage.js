/**
 * ============================================================================
 *  EAC — STOCKAGE / MINI "BACK-OFFICE" CLIENT (localStorage)
 * ============================================================================
 *  Ce module permet de sauvegarder des modifications de contenu directement
 *  dans le navigateur (texte, images en base64, liens, vidéos) sans backend
 *  serveur. Utilisé par admin.html pour éditer le site, et par index.html
 *  pour lire les valeurs personnalisées par-dessus le contenu par défaut.
 * ============================================================================
 */
(function (global) {
  "use strict";

  const STORAGE_KEY = "eac_content_overrides_v1";
  const MAX_IMAGE_BYTES = 1.8 * 1024 * 1024; // ~1.8MB par image uploadée (sécurité quota)

  function safeParse(json, fallback) {
    try { return JSON.parse(json); } catch (e) { return fallback; }
  }

  function loadOverrides() {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? safeParse(raw, {}) : {};
  }

  function saveOverrides(obj) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
      return true;
    } catch (e) {
      console.error("Erreur de sauvegarde (quota dépassé ?)", e);
      return false;
    }
  }

  function clearOverrides() {
    localStorage.removeItem(STORAGE_KEY);
  }

  /**
   * Fusion profonde : les tableaux dans overrides remplacent totalement ceux
   * du défaut (édition par listes complètes gérée côté admin), les objets
   * simples sont fusionnés clé par clé.
   */
  function deepMerge(base, override) {
    if (Array.isArray(override)) return override.slice();
    if (override && typeof override === "object") {
      const out = Array.isArray(base) ? base.slice() : Object.assign({}, base);
      Object.keys(override).forEach((key) => {
        if (
          base && typeof base === "object" && key in base &&
          typeof base[key] === "object" && base[key] !== null &&
          typeof override[key] === "object" && override[key] !== null
        ) {
          out[key] = deepMerge(base[key], override[key]);
        } else {
          out[key] = override[key];
        }
      });
      return out;
    }
    return override !== undefined ? override : base;
  }

  function getContent() {
    const defaults = global.EAC_DEFAULT_CONTENT || {};
    const overrides = loadOverrides();
    return deepMerge(defaults, overrides);
  }

  function setContent(newContent) {
    return saveOverrides(newContent);
  }

  function resetContent() {
    clearOverrides();
  }

  function exportJSON() {
    return JSON.stringify(getContent(), null, 2);
  }

  function importJSON(jsonString) {
    const parsed = safeParse(jsonString, null);
    if (!parsed) return false;
    return saveOverrides(parsed);
  }

  /** Lit un fichier <input type="file"> et le convertit en data-URL, avec limite de taille. */
  function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
      if (!file) return reject(new Error("Aucun fichier sélectionné."));
      if (file.size > MAX_IMAGE_BYTES) {
        return reject(new Error("Fichier trop volumineux (max ~1.8 Mo). Compressez l'image avant import."));
      }
      const allowed = ["image/jpeg", "image/png", "image/webp", "image/svg+xml", "image/gif"];
      if (!allowed.includes(file.type)) {
        return reject(new Error("Type de fichier non autorisé. Utilisez JPG, PNG, WEBP, GIF ou SVG."));
      }
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Impossible de lire le fichier."));
      reader.readAsDataURL(file);
    });
  }

  /** Échappe le HTML pour affichage sûr (protection XSS des champs texte admin). */
  function escapeHTML(str) {
    if (str === null || str === undefined) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /**
   * SÉCURITÉ — Valide qu'une URL destinée à un attribut href/src est sûre.
   * Bloque les schémas dangereux (javascript:, vbscript:, data: sur des liens,
   * etc.) qui pourraient être injectés via le panneau admin, un import JSON,
   * ou un champ "lien" mal renseigné. Autorise: vide, "#", chemins relatifs,
   * http(s):, mailto:, tel:. Pour les images, data: est géré séparément
   * (voir isSafeImageSrc) car les imports admin produisent des data-URL.
   */
  const SAFE_LINK_SCHEMES = /^(https?:|mailto:|tel:)/i;
  const DANGEROUS_SCHEME = /^\s*(javascript|vbscript|data|file):/i;
  function isSafeUrl(url) {
    if (url === null || url === undefined) return true; // vide = ok (retombe sur "#")
    const trimmed = String(url).trim();
    if (trimmed === "" || trimmed === "#") return true;
    if (DANGEROUS_SCHEME.test(trimmed)) return false;
    if (SAFE_LINK_SCHEMES.test(trimmed)) return true;
    // Chemins relatifs ou ancres (#section, images/x.jpg, ./page.html, /path)
    if (/^[a-zA-Z0-9#./_-]/.test(trimmed)) return true;
    return false;
  }

  /** Variante pour attributs src d'image : autorise en plus data:image/*. */
  function isSafeImageSrc(url) {
    if (url === null || url === undefined) return true;
    const trimmed = String(url).trim();
    if (/^data:image\/(png|jpeg|jpg|gif|webp|svg\+xml);base64,/i.test(trimmed)) return true;
    return isSafeUrl(trimmed);
  }

  /* ============================ SESSION ADMIN (indicateur local) ============================
     Le site étant 100% statique, il n'existe pas de vraie authentification
     serveur. Ce indicateur sert uniquement à savoir, dans CE navigateur, si
     la personne a déjà ouvert le panneau d'administration — afin d'afficher
     un lien "Se déconnecter" fonctionnel plutôt qu'un lien "Espace
     administration" visible en permanence pour tout le monde. Voir
     SECURITY.md pour les recommandations de sécurisation réelle (accès
     protégé côté serveur).
  ============================================================================= */
  const ADMIN_SESSION_KEY = "eac_admin_active";
  function isAdminSession() {
    return localStorage.getItem(ADMIN_SESSION_KEY) === "1";
  }
  function startAdminSession() {
    localStorage.setItem(ADMIN_SESSION_KEY, "1");
  }
  function endAdminSession() {
    localStorage.removeItem(ADMIN_SESSION_KEY);
  }

  global.EAC_STORAGE = {
    getContent,
    setContent,
    resetContent,
    exportJSON,
    importJSON,
    fileToDataURL,
    escapeHTML,
    isSafeUrl,
    isSafeImageSrc,
    loadOverrides,
    saveOverrides,
    isAdminSession,
    startAdminSession,
    endAdminSession
  };
})(window);
