/**
 * ============================================================================
 *  EAC — CONTENU PAR DÉFAUT (base de données du site)
 * ============================================================================
 *  Ce fichier centralise TOUT le contenu modifiable du site : équipe, jeux,
 *  galerie, vidéos, partenaires, tarifs, FAQ, coordonnées...
 *
 *  COMMENT REMPLACER VOS PROPRES IMAGES / VIDÉOS / FICHIERS :
 *  1) Déposez votre fichier dans le bon dossier :
 *       - Photos d'équipe   -> assets/img/team/
 *       - Jaquettes de jeux -> assets/img/games/
 *       - Galerie / slider  -> assets/img/slider/
 *       - Logos partenaires -> assets/img/partners/
 *       - Vidéos            -> assets/video/
 *       - Documents (PDF…)  -> assets/docs/
 *  2) Changez le chemin "img" ou "video" ci-dessous pour pointer vers votre
 *     nouveau fichier (même nom ou nom différent, peu importe).
 *  3) Enregistrez — c'est tout, aucune connaissance en code n'est requise.
 *
 *  Vous pouvez aussi tout gérer visuellement depuis le panneau d'administration
 *  du site : ouvrez /admin.html (voir README.md pour plus de détails).
 * ============================================================================
 */
window.EAC_DEFAULT_CONTENT = {

  site: {
    name: "Enter Africa Cameroun",
    shortName: "EAC",
    logo: "assets/img/logo.png",
    tagline: "Gamification, création de jeux vidéo et formation numérique au Cameroun.",
    email: "contact@eac-cameroun.org",
    phone: "+237 6 99 99 99 99",
    address: "Goethe-Institut, Yaoundé, Cameroun",
    hours: "Lun - Ven : 9h - 17h",
    social: {
      facebook: "#",
      linkedin: "#",
      youtube: "#"
    },
    rgpdContent: "<p>Enter Africa Cameroun (EAC) attache une grande importance à la protection de vos données personnelles.</p><p><strong>Données collectées :</strong> nom, email, téléphone (si fourni), et messages envoyés via nos formulaires de contact, de rendez-vous ou d'inscription à notre guide gratuit.</p><p><strong>Utilisation :</strong> ces données servent uniquement à répondre à vos demandes, vous recontacter, ou vous envoyer les documents demandés. Elles ne sont jamais vendues ni partagées avec des tiers à des fins commerciales.</p><p><strong>Conservation :</strong> vos données sont conservées le temps nécessaire au traitement de votre demande.</p><p><strong>Vos droits :</strong> vous pouvez à tout moment demander l'accès, la correction ou la suppression de vos données en nous contactant à l'adresse indiquée sur notre page Contact.</p><p><em>Cette page sera complétée avec notre politique de confidentialité définitive. Pour toute question, contactez-nous directement.</em></p>",
    savContent: "<p>Notre service après-vente (SAV) est là pour vous accompagner après votre inscription à une formation, un atelier ou un accompagnement EAC.</p><p><strong>Comment nous contacter :</strong> utilisez le formulaire de la page Contact, ou écrivez-nous directement par email — nous répondons généralement sous 48h ouvrées.</p><p><strong>Questions fréquentes :</strong> pour les questions courantes (tarifs, contenu des formations, modalités d'inscription), consultez d'abord notre FAQ sur la page Services.</p><p><em>Un espace SAV plus complet (suivi de dossier, tickets d'assistance) sera mis en ligne prochainement.</em></p>"
  },

  /* Organisations et ressources externes du secteur du jeu vidéo africain —
     utilisées dans la recherche et sur la page Services (section Réseau). */
  externalResources: [
    { name: "Goethe-Institut Kamerun", url: "https://www.goethe.de/ins/cm/fr/index.html", desc: "Partenaire fondateur d'Enter Africa Cameroun." },
    { name: "IGDA — International Game Developers Association", url: "https://igda.org/", desc: "Association internationale des développeurs de jeux vidéo." },
    { name: "AEC Africa", url: "https://aec.africa/", desc: "Confédération africaine de l'esport." },
    { name: "Games Week Africa", url: "https://gamesweek.africa/", desc: "Événement annuel dédié au jeu vidéo en Afrique." },
    { name: "Games Industry Africa", url: "https://gamesindustryafrica.com/", desc: "Actualités et analyses de l'industrie africaine du jeu vidéo." },
    { name: "GAMR Africa", url: "https://gamr.africa/", desc: "Plateforme dédiée à l'écosystème du gaming africain." },
    { name: "Sages Africa", url: "https://sages.africa/", desc: "Acteur du développement du secteur des jeux vidéo en Afrique." },
    { name: "SensCritique — Afrique et jeu vidéo", url: "https://www.senscritique.com/liste/afrique_et_jeu_video/2056046", desc: "Liste collaborative de jeux vidéo liés à l'Afrique." },
    { name: "Social Net Link — Studios africains unis (PAGG)", url: "https://www.socialnetlink.org/2022/02/23/les-10-meilleurs-studios-de-jeux-video-africains-sunissent-pour-creer-un-editeur-continental-pagg/", desc: "10 studios africains s'unissent pour créer un éditeur continental." },
    { name: "Gamescom Global", url: "https://www.gamescom.global/", desc: "Le plus grand salon mondial du jeu vidéo, où EAC a représenté l'Afrique." }
  ],

  hero: {
    titleHtml: "Bienvenue sur <span>ENTER</span>-<span>AFRICA</span>-CAMEROUN",
    welcomeHtml: "Vous êtes _ <span class=\"ch-v\">Chez Vous !</span>",
    ctaText: "ICI",
    ctaTarget: "#contact",
    subText: "Commencez Gamers"
  },

  genese: {
    title: "Genèse EAC",
    html: "Projet initié par le Goethe-Institut Addis Abbeba (Éthiopie), notamment le Dr Julia SATTLER et Stéfanie KASTNER du Goethe Afrique du Sud. <span>ENTER AFRICA</span> réunit 15 pays, autour du tryptique : « Passé », <span>Présent</span> et « Futur ».<br><br>Il s'agit d'utiliser les techniques et méthodes de la Gamification, pour la Re-création, la Valorisation et la Projection, par le jeu, de nos sociétés <span>Africaines</span>.<br><br>Par différents leviers dont : le prototypage, l'infographie de conception &amp; d'autres artistiques ou de programmation (logiciel « Espoto »), issus des jeux traditionnels, de la vidéo, mieux, du digital ; l'on se projette par le numérique dans un écosystème plus équilibré.<br><br>Au Cameroun, différentes personnalités, compétences (C. Deeg, D. Bedilu) et/ou savoir-faire ont permis de donner vie à ces nouveaux savoirs locaux/interculturels.<br><br>Suivant cette logique de transmission des savoirs, le projet <span>EAC</span> est lancé en juin 2018, au Goethe-Institut Kamerun.<br><br>Au terme de ladite <span>Formation</span>, une vingtaine de Camerounais·es, plutôt jeunes, arriveront à produire quelques jeux numériques (Ongola Land, Voyageur) et un Méga Jeu analogique (Busara), en commun avec les 14 autres pays.<br><br>Cette entrée « Spectaculaire » dans le monde de la Ludification, du Gaming, du Virtuel, de la Réalité Augmentée, du Numérique et de l'Holographique, rendra concret un vieux rêve créatif partagé : celui de la « Transformation », par les moyens de la Gamification et du « Jeu », de nos sociétés conjointes. Progrès bienveillants, vers une certaine « Perfectibilité ».",
    video: {
      youtubeId: "HKSCa_hior8",
      poster: "assets/img/games/ongola-land.jpg",
      alt: "Vidéo de lancement du jeu Ongola Land"
    }
  },

  presentationTitleHtml: "Présentation <span>EAC</span> / Ongola Land (2018-2019)",

  gallery: [
    { title: "Institut Goethe Kamerun", img: "assets/img/partners/goethe-institut-building.jpg", link: "https://www.goethe.de/ins/cm/fr/index.htm" },
    { title: "Team EAC — Formation 2018", img: "assets/img/team/formation-2018-group.jpg", link: "" },
    { title: "Justin ZEH / Président EAC", img: "assets/img/team/justin-zeh.jpg", link: "" },
    { title: "Patrick TOUKO / Resp. Finance EAC", img: "assets/img/team/patrick-touko.jpg", link: "" },
    { title: "Fabian Mühlthaler / DG Goethe 2018-2019", img: "assets/img/team/fabian-muhlthaler.jpg", link: "https://www.goethe.de/ins/cm/fr/ueb/ver.cfm" },
    { title: "Edith Kouekam / Adm. Goethe.I.K / EAC", img: "assets/img/team/edith-kouekam.jpg", link: "" },
    { title: "Raphael Mouchango / Goethe.I.K, Supv. EAC", img: "assets/img/team/raphael-mouchango.jpg", link: "" },
    { title: "Dr. Julia Sattler / Directrice de Projet EA", img: "assets/img/team/julia-sattler.jpg", link: "" },
    { title: "Mbiappa William / Juriste, CC-EAC", img: "assets/img/team/mbiappa-william.jpg", link: "" },
    { title: "Abraham Zogo / Philosophe, CC-EAC", img: "assets/img/team/abraham-zogo.jpg", link: "" },
    { title: "Zogo Benoit / Économiste, Finance EAC", img: "assets/img/team/zogo-benoit.jpg", link: "" },
    { title: "Cédrick Minlo", img: "assets/img/team/cedric-minlo.jpg", link: "" },
    { title: "Évélia G., Membre EAC", img: "assets/img/team/evelia-g.jpg", link: "" },
    { title: "Amos Njitam, Scénariste, EAC", img: "assets/img/team/amos-njitam.jpg", link: "" },
    { title: "Xavier Aurélien, Développeur, EAC", img: "assets/img/team/xavier-aurelien.jpg", link: "" },
    { title: "Hugo Tchoumegni, Consultant EAC", img: "assets/img/team/hugo-tchoumegni.jpg", link: "" },
    { title: "Aurion — Olivier Madiba (Kiro'o Games)", img: "assets/img/team/aurion-artwork.jpg", link: "" },
    { title: "Julien Eboko, Comédien, Auteur, EAC", img: "assets/img/team/julien-eboko.jpg", link: "" },
    { title: "Nina Fink, Organisation EA", img: "assets/img/team/nina-fink.jpg", link: "" },
    { title: "Jim Ntube Epie, Plasticien, EAC", img: "assets/img/team/jim-ntube-epie.jpg", link: "" },
    { title: "Busara, EA", img: "assets/img/games/busara.jpg", link: "games.html" },
    { title: "Ongola Land, EA", img: "assets/img/games/ongola-land.jpg", link: "games.html" },
    { title: "Voyageur, jeu vidéo EAC", img: "assets/img/games/voyageur.png", link: "games.html" },
    { title: "Quelques jeux EA", img: "assets/img/games/collection-eac.jpg", link: "games.html" },
    { title: "Festival Pousse Pions", img: "assets/img/games/pousse-pions-festival.jpg", link: "" },
    { title: "Didier Demassosso, Psychologue, EAC", img: "assets/img/team/didier-demassosso.jpg", link: "" },
    { title: "Darius Dada, Artiste Pluriel, EAC", img: "assets/img/team/darius-dada.jpg", link: "" },
    { title: "Pipa Richard, Régisseur Général, Goethe.I.K", img: "assets/img/team/pipa-richard-kaka.jpg", link: "" },
    { title: "Dr. John Mbapou / V.Pr-EAC", img: "assets/img/team/john-mbapou.jpg", link: "" },
    { title: "Landry Mbassi, Curateur, EAC", img: "assets/img/team/landry-mbassi.jpg", link: "" },
    { title: "Lydol / Dolly Sorel Nwafo, COM Goethe.I.K, EAC", img: "assets/img/team/lydol-dolly-sorel-nwafo.jpg", link: "" },
    { title: "Gilbert Koloko / SG-EAC", img: "assets/img/team/gilbert-koloko.jpg", link: "" },
    { title: "Stephanie Kastner, Directrice de Projet EA", img: "assets/img/team/stephanie-kastner.jpg", link: "" },
    { title: "Christopher Deeg, Formateur, EA", img: "assets/img/team/christopher-deeg.jpg", link: "" },
    { title: "Jean Claude Awono, Directeur Ifrikia, EAC", img: "assets/img/team/jean-claude-awono.jpg", link: "" },
    { title: "Dagmawi Bedilu, Formateur, EA", img: "assets/img/team/dagmawi-bedilu.jpg", link: "" },
    { title: "Enter Africa International — Réseau 15 pays", img: "assets/img/slider/enter-africa-15-countries.jpg", link: "" },
    { title: "Food-H, jeu de John Mbapou", img: "assets/img/games/food-h.jpg", link: "assets/games/food-h/index.html" },
    { title: "Esports Cameroun — Games of the Future, Kazan 2024", img: "assets/img/slider/esports-cameroun.jpg", link: "" },
    { title: "SpielFabrique — Partenaire", img: "assets/img/partners/spielfabrique.png", link: "" },
    { title: "ENSPY — Partenaire", img: "assets/img/partners/enspy.png", link: "" },

    // --- Vidéos EAC (légende cliquable → YouTube) ---
    { title: "Metheore Consulting", img: "assets/img/partners/metheore-consulting.jpg", link: "", videoUrl: "https://youtu.be/XLplhzA8vJo" },
    { title: "Lancement jeu Ongola Land", img: "assets/img/games/ongola-land.jpg", link: "", videoUrl: "https://youtu.be/HKSCa_hior8" },
    { title: "ESPOTO Tutorial", img: "assets/img/bonus/ongola-land-alt-cover.png", link: "", videoUrl: "https://youtu.be/uGfrvauDHhQ" },
    { title: "Enter Africa Presentation", img: "assets/img/logo.png", link: "", videoUrl: "https://youtu.be/56JQ9Wiv2qA" },
    { title: "Ongola Land — Enter Africa (teaser)", img: "assets/img/games/ongola-land.jpg", link: "", videoUrl: "https://youtu.be/C09lRdlDZBk" },
    { title: "EAC Vidéo 3", img: "assets/img/games/collection-eac.jpg", link: "", videoUrl: "https://youtu.be/KNOQ1vRd41w" },
    { title: "EAC Vidéo — Coulisses", img: "assets/img/team/formation-2018-group.jpg", link: "", videoUrl: "https://youtu.be/McadugGqEXg" }
  ],

  // Vidéos utilisées sur la page Jeux (grille "Parcours & jeux EAC en vidéos")
  videos: [
    { title: "Lancement jeu Ongola Land", channel: "Enter Africa Cameroun", youtubeId: "HKSCa_hior8" },
    { title: "Ongola Land — Enter Africa (teaser)", channel: "Enter Africa Cameroun", youtubeId: "C09lRdlDZBk" },
    { title: "Enter Africa Presentation", channel: "Enter Africa Cameroun", youtubeId: "56JQ9Wiv2qA" },
    { title: "ESPOTO Tutorial — Creating Custom Maps", channel: "Enter Africa Cameroun", youtubeId: "uGfrvauDHhQ" },
    { title: "Reliving EnterAfrica", channel: "Enter Africa Cameroun", youtubeId: "GP7ZAiHIRFg" },
    { title: "Metheore Consulting", channel: "Enter Africa Cameroun", youtubeId: "XLplhzA8vJo" },
    { title: "EAC Vidéo 3", channel: "Enter Africa Cameroun", youtubeId: "KNOQ1vRd41w" },
    { title: "EAC Vidéo — Coulisses", channel: "Enter Africa Cameroun", youtubeId: "McadugGqEXg" }
  ],

  slider: [
    { icon: "1", img: "assets/img/slider/c1.jpg", titleHtml: "Local Game <span>O-L</span>", desc: "Le jeu numérique Ongola Land, sur l'histoire du Cameroun" },
    { icon: "2", img: "assets/img/slider/c2.jpg", titleHtml: "<span>BUSARA</span> - EA", desc: "Le plateau du jeu analogique Busara (EA)" },
    { icon: "3", img: "assets/img/slider/c3.jpg", titleHtml: "Les <span>Formateurs</span>", desc: "ENTER AFRICA trainers, rencontre au stand Enter Africa" },
    { icon: "4", img: "assets/img/slider/c4.jpg", titleHtml: "Launching <span>EAC</span>", desc: "Le DG Goethe, Fabian Mühlthaler, remet un prix lors du lancement" },
    { icon: "5", img: "assets/img/slider/c5.jpg", titleHtml: "<span>Gaming</span> Party 3.0", desc: "Encadreurs du Goethe Institut Kamerun et Membres EAC, + notre fidèle public" },
    { icon: "6", img: "assets/img/slider/c6.jpg", titleHtml: "Fin de <span>Formation</span>", desc: "Cérémonie de remise des diplômes, membres EAC" },
    { icon: "7", img: "assets/img/slider/c7.jpg", titleHtml: "<span>Rencontre</span> Enter Africa", desc: "Membres de l'équipe internationale Enter Africa" },
    { icon: "8", img: "assets/img/slider/c8.jpg", titleHtml: "<span>Games</span> Festival", desc: "Festival Pousse Pions — jeux de société de Yaoundé" },
    { icon: "9", img: "assets/img/slider/c9.jpg", titleHtml: "<span>EA</span>-Gamescom", desc: "L'équipe ENTER AFRICA à la Gamescom 2019" },
    { icon: "10", img: "assets/img/slider/c10.jpg", titleHtml: "<span>Échanges</span> EAC", desc: "Moment d'échange entre membres et partenaires EAC" },
    { icon: "11", img: "assets/img/slider/c11.jpg", titleHtml: "Direction <span>Team EA</span>", desc: "L'équipe de direction du réseau international Enter Africa" },
    { icon: "12", img: "assets/img/slider/c12.jpg", titleHtml: "Lancement <span>Ongola Land</span>", desc: "Dévoilement des affiches du jeu Ongola Land à Yaoundé" }
  ],

  vision2030: {
    titleHtml: "Enter Africa Cameroun <span>_2030</span>",
    visionTitle: "OUR VISION",
    visionHtml: "Notre objectif est de former aux métiers du numérique, des jeux analogiques et vidéos, du virtuel et de la réalité augmentée <span>3000 Jeunes</span> Africains et plus, d'ici <span>2030</span>.",
    visionHtml2: "Et faire de <span>EAC</span> un pôle futuriste de développement par les nouvelles technologies.",
    ctaText: "EAC-2030",
    processTitle: "OUR PROCESS",
    process: [
      "Gamification",
      "Formation",
      "Games-Jam / Parties",
      "Ateliers et Recyclages Numériques",
      "Création de <span>12 jeux</span> d'ici <span>2030</span>"
    ],
    partnersTitle: "WITH WHOM ?",
    partners: [
      "Enter Africa / Goethe-Institut Kamerun",
      "Electronic Arts Games ?!",
      "ENSPY",
      "Metheore Consulting",
      "Spielfabrique",
      "Université de Yaoundé I",
      "Gamescom",
      "Tokyo Game Show ?!"
    ]
  },

  team: {
    title: "EAC-Team / Launching Game 2019",
    img: "assets/img/team/eac-team-group.jpg"
  },

  services: [
    { icon: "fa-comments", title: "Consulting", desc: "Analyse, game design, narration." },
    { icon: "fa-chalkboard-teacher", title: "Formation", desc: "Initiation au game design, programmation." },
    { icon: "fa-gamepad", title: "Gamification", desc: "Mécaniques de jeu pour vos projets." },
    { icon: "fa-handshake", title: "Accompagnement", desc: "Suivi personnalisé de A à Z." }
  ],

  prices: [
    { name: "Pass Découverte", price: "3$", period: "/mois", items: ["Accès à la démo d'Ongola Land", "Accès au serveur Discord EAC", "1 replay d'atelier en ligne/mois", "Badge communauté numérique", "Newsletter jeux & bons plans"], featured: false },
    { name: "Pass Joueur", price: "8$", period: "/mois", items: ["Ongola Land complet + mises à jour", "Kit numérique du jeu Busara", "Accès prioritaire aux bêtas EAC", "1 Game Night en ligne/mois", "Réduction sur les ateliers présentiels", "Support par email prioritaire"], featured: true },
    { name: "Pass Créateur", price: "15$", period: "/mois", items: ["Tous les jeux EAC (Ongola Land, Busara, Voyageur)", "1 session mentorat 1-to-1/mois", "Crédit de 20% sur une formation EAC", "Accès anticipé aux nouveaux jeux", "Merch numérique exclusif (fonds d'écran, badges)", "Support prioritaire + accès communauté créateurs"], featured: false }
  ],

  faq: [
    { q: "Qu'est-ce que EAC ?", a: "EAC est une association de passionnés de jeux vidéo et de gamification, basée au Cameroun, qui forme les jeunes et crée des jeux africains." },
    { q: "Quel est votre objectif ?", a: "Promouvoir les cultures africaines par le jeu, former aux métiers du numérique et créer un écosystème de jeux vidéo en Afrique." },
    { q: "Où êtes-vous situés ?", a: "Nous sommes basés au Goethe-Institut de Yaoundé et travaillons en collaboration avec le Ministère de la Culture du Cameroun." },
    { q: "Puis-je créer mon propre jeu avec vous ?", a: "Oui ! Nous vous accompagnons de la conception à la réalisation, en passant par la formation et le prototypage." }
  ],

  games: [
    { title: "Ongola Land", desc: "Jeu numérique sur l'histoire du Cameroun.", img: "assets/img/games/ongola-land.jpg", link: "" },
    { title: "Busara", desc: "Méga jeu analogique stratégique.", img: "assets/img/games/busara.jpg", link: "" },
    { title: "Voyageur", desc: "Mini-jeu numérique Cameroun-Belgique.", img: "assets/img/games/voyageur.png", link: "" },
    { title: "Food-H", desc: "Jeu mobile de sensibilisation au gaspillage alimentaire, par John Mbapou.", img: "assets/img/games/food-h.jpg", link: "assets/games/food-h/index.html" },
    { title: "Autres jeux", desc: "Découvrez notre collection complète.", img: "assets/img/games/collection-eac.jpg", link: "" }
  ],

  capture: {
    title: "Recevez notre guide gratuit",
    desc: "La checklist complète des éléments à vérifier avant de publier un site web — inscrivez-vous avec votre email pour la recevoir.",
    pdfPreview: "assets/img/games/collection-eac.jpg",
    pdfFile: "assets/docs/checklist-avant-publication-site-web.pdf"
  },

  searchExtra: [
    { title: "Vidéo Présentation EAC", type: "vidéo", url: "index.html#home", excerpt: "Découvrez EAC et le lancement d'Ongola Land." },
    { title: "Formation Game Design", type: "formation", url: "services.html", excerpt: "Devenez créateur de jeux vidéo avec EAC." }
  ]
};
