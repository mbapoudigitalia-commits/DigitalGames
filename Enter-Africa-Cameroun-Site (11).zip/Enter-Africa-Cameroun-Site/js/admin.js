/**
 * ============================================================================
 *  EAC — ADMIN.JS — Panneau d'administration (mini CMS local)
 * ============================================================================
 *  Édite le contenu du site (texte, images, liens) et l'enregistre dans
 *  localStorage via EAC_STORAGE. Aucune connaissance en code n'est requise.
 * ============================================================================
 */
(function () {
  "use strict";

  const esc = window.EAC_STORAGE.escapeHTML;
  let working = window.EAC_STORAGE.getContent(); // copie de travail

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }
  function el(tag, attrs, html) {
    const node = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => {
      if (k === "class") node.className = attrs[k]; else node.setAttribute(k, attrs[k]);
    });
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function toast(message, isError) {
    const container = $("#toastContainer");
    const t = el("div", { class: "toast" }, esc(message));
    if (isError) t.style.borderColor = "var(--color-tertiary)";
    container.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }

  /** Accepte un ID YouTube brut ou une URL complète (youtu.be/... ou
   *  youtube.com/watch?v=...) et retourne uniquement l'identifiant. */
  function extractYoutubeId(value) {
    if (!value) return "";
    const v = value.trim();
    const shortMatch = v.match(/youtu\.be\/([a-zA-Z0-9_-]{6,})/);
    if (shortMatch) return shortMatch[1];
    const longMatch = v.match(/[?&]v=([a-zA-Z0-9_-]{6,})/);
    if (longMatch) return longMatch[1];
    const embedMatch = v.match(/embed\/([a-zA-Z0-9_-]{6,})/);
    if (embedMatch) return embedMatch[1];
    // Sinon on considère que c'est déjà un identifiant brut (on ne garde que
    // les caractères valides pour un ID YouTube, par sécurité)
    return v.replace(/[^a-zA-Z0-9_-]/g, "");
  }

  /**
   * SÉCURITÉ — Filet de sécurité global : passe sur TOUT le contenu de
   * travail juste avant sauvegarde et neutralise tout lien ou source
   * d'image qui ne respecterait pas isSafeUrl/isSafeImageSrc. S'applique
   * quel que soit l'onglet enregistré, et couvre aussi un JSON importé.
   */
  function sanitizeWorkingContent() {
    let cleaned = 0;
    const cleanLink = (v) => {
      if (v && !window.EAC_STORAGE.isSafeUrl(v)) { cleaned++; return ""; }
      return v;
    };
    const cleanImg = (v) => {
      if (v && !window.EAC_STORAGE.isSafeImageSrc(v)) { cleaned++; return "assets/img/logo.png"; }
      return v;
    };
    (working.gallery || []).forEach((it) => { it.link = cleanLink(it.link); it.videoUrl = cleanLink(it.videoUrl); it.img = cleanImg(it.img); });
    (working.games || []).forEach((it) => { it.link = cleanLink(it.link); it.img = cleanImg(it.img); });
    if (working.site && working.site.social) {
      working.site.social.facebook = cleanLink(working.site.social.facebook);
      working.site.social.linkedin = cleanLink(working.site.social.linkedin);
      working.site.social.youtube = cleanLink(working.site.social.youtube);
    }
    if (working.site) working.site.logo = cleanImg(working.site.logo);
    if (working.team) working.team.img = cleanImg(working.team.img);
    if (working.genese && working.genese.video) {
      working.genese.video.youtubeId = extractYoutubeId(working.genese.video.youtubeId);
      working.genese.video.poster = cleanImg(working.genese.video.poster);
    }
    if (working.capture) {
      working.capture.pdfFile = cleanLink(working.capture.pdfFile);
      working.capture.pdfPreview = cleanImg(working.capture.pdfPreview);
    }
    if (cleaned > 0) toast(`${cleaned} lien(s)/image(s) invalide(s) ont été neutralisés pour votre sécurité.`, true);
    return cleaned;
  }

  function persist(successMsg) {
    sanitizeWorkingContent();
    const ok = window.EAC_STORAGE.setContent(working);
    toast(ok ? (successMsg || "Modifications enregistrées !") : "Erreur : quota de stockage dépassé.", !ok);
  }

  /* ============================ NAVIGATION ONGLETS ============================ */
  $all(".admin-nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      $all(".admin-nav-btn").forEach((b) => b.classList.remove("active"));
      $all(".admin-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      $("#panel-" + btn.dataset.tab).classList.add("active");
    });
  });

  /* ============================ GÉNÉRAL ============================ */
  function loadGeneral() {
    const s = working.site || {};
    $("#g-name").value = s.name || "";
    $("#g-shortname").value = s.shortName || "";
    $("#g-email").value = s.email || "";
    $("#g-phone").value = s.phone || "";
    $("#g-address").value = s.address || "";
    $("#g-hours").value = s.hours || "";
    $("#g-tagline").value = s.tagline || "";
    $("#g-facebook").value = (s.social && s.social.facebook) || "";
    $("#g-linkedin").value = (s.social && s.social.linkedin) || "";
    $("#g-youtube").value = (s.social && s.social.youtube) || "";
    $("#g-logo-preview").src = s.logo || "assets/img/logo.png";
    $("#g-rgpd").value = s.rgpdContent || "";
    $("#g-sav").value = s.savContent || "";
  }
  $("#g-logo-file").addEventListener("change", async function () {
    if (!this.files[0]) return;
    try {
      const dataUrl = await window.EAC_STORAGE.fileToDataURL(this.files[0]);
      $("#g-logo-preview").src = dataUrl;
    } catch (e) { toast(e.message, true); }
  });
  $('[data-save="general"]').addEventListener("click", () => {
    working.site = Object.assign({}, working.site, {
      name: $("#g-name").value, shortName: $("#g-shortname").value, email: $("#g-email").value,
      phone: $("#g-phone").value, address: $("#g-address").value, hours: $("#g-hours").value,
      tagline: $("#g-tagline").value, logo: $("#g-logo-preview").src,
      social: { facebook: $("#g-facebook").value, linkedin: $("#g-linkedin").value, youtube: $("#g-youtube").value },
      rgpdContent: $("#g-rgpd").value, savContent: $("#g-sav").value
    });
    persist("Informations générales enregistrées !");
  });

  /* ============================ ACCUEIL ============================ */
  function loadAccueil() {
    const h = working.hero || {}, g = working.genese || {};
    $("#h-title").value = h.titleHtml || "";
    $("#h-welcome").value = h.welcomeHtml || "";
    $("#h-genese-title").value = g.title || "";
    $("#h-genese-text").value = g.html || "";
    $("#h-video-src").value = (g.video && g.video.youtubeId) || "";
    $("#h-video-poster-preview").src = (g.video && g.video.poster) || "assets/img/logo.png";
  }
  $("#h-video-poster-file").addEventListener("change", async function () {
    if (!this.files[0]) return;
    try {
      const dataUrl = await window.EAC_STORAGE.fileToDataURL(this.files[0]);
      $("#h-video-poster-preview").src = dataUrl;
    } catch (e) { toast(e.message, true); }
  });
  $('[data-save="accueil"]').addEventListener("click", () => {
    working.hero = Object.assign({}, working.hero, { titleHtml: $("#h-title").value, welcomeHtml: $("#h-welcome").value });
    working.genese = Object.assign({}, working.genese, {
      title: $("#h-genese-title").value,
      html: $("#h-genese-text").value,
      video: { youtubeId: extractYoutubeId($("#h-video-src").value), poster: $("#h-video-poster-preview").src, alt: working.genese.video ? working.genese.video.alt : "" }
    });
    persist("Page d'accueil enregistrée !");
  });

  /* ============================ GÉNÉRATEUR DE LISTES (galerie, jeux, services, tarifs, faq) ============================ */
  function renderImageListEditor(containerId, items, fields, onAdd) {
    const container = $("#" + containerId);
    container.innerHTML = "";
    items.forEach((item, index) => {
      const card = el("div", { class: "admin-card" });
      const imgSrc = item[fields.imageKey] || "assets/img/logo.png";
      const imgHtml = fields.imageKey ? `<img src="${imgSrc}" class="admin-thumb" alt="">` : "";
      card.innerHTML = `
        ${imgHtml}
        <div class="admin-card-fields"></div>
        <button type="button" class="admin-card-remove" aria-label="Supprimer"><i class="fas fa-trash"></i></button>
      `;
      const fieldsWrap = card.querySelector(".admin-card-fields");
      fields.textFields.forEach((f) => {
        const input = f.multiline ? el("textarea", { placeholder: f.label, rows: "2" }) : el("input", { type: f.type || "text", placeholder: f.label });
        input.value = item[f.key] || "";
        input.addEventListener("input", () => { item[f.key] = input.value; });
        fieldsWrap.appendChild(input);
      });
      if (fields.imageKey) {
        const fileInput = el("input", { type: "file", accept: "image/*" });
        fileInput.addEventListener("change", async () => {
          if (!fileInput.files[0]) return;
          try {
            const dataUrl = await window.EAC_STORAGE.fileToDataURL(fileInput.files[0]);
            item[fields.imageKey] = dataUrl;
            card.querySelector("img").src = dataUrl;
          } catch (e) { toast(e.message, true); }
        });
        fieldsWrap.appendChild(fileInput);
      }
      if (fields.checkbox) {
        const row = el("label", { class: "admin-checkbox-row" });
        const cb = el("input", { type: "checkbox" });
        cb.checked = !!item[fields.checkbox.key];
        cb.addEventListener("change", () => { item[fields.checkbox.key] = cb.checked; });
        row.appendChild(cb);
        row.appendChild(document.createTextNode(fields.checkbox.label));
        fieldsWrap.appendChild(row);
      }
      card.querySelector(".admin-card-remove").addEventListener("click", () => {
        items.splice(index, 1);
        renderImageListEditor(containerId, items, fields, onAdd);
      });
      container.appendChild(card);
    });
    if (items.length === 0) {
      container.appendChild(el("p", { class: "admin-empty" }, "Aucun élément pour le moment. Cliquez sur « Ajouter » pour commencer."));
    }
  }

  // --- Galerie ---
  function refreshGallery() {
    renderImageListEditor("gallery-list", working.gallery, {
      imageKey: "img",
      textFields: [
        { key: "title", label: "Titre" },
        { key: "link", label: "Lien (optionnel)" },
        { key: "videoUrl", label: "Lien vidéo YouTube (optionnel — prioritaire sur le lien ci-dessus)" }
      ]
    });
  }
  $("#gallery-add").addEventListener("click", () => {
    working.gallery.push({ title: "Nouvelle carte", img: "assets/img/logo.png", link: "" });
    refreshGallery();
  });
  $('[data-save="gallery"]').addEventListener("click", () => persist("Galerie enregistrée !"));

  // --- Team (photo unique) ---
  function loadTeam() {
    $("#team-title").value = (working.team && working.team.title) || "";
    $("#team-img-preview").src = (working.team && working.team.img) || "assets/img/logo.png";
  }
  $("#team-img-file").addEventListener("change", async function () {
    if (!this.files[0]) return;
    try {
      const dataUrl = await window.EAC_STORAGE.fileToDataURL(this.files[0]);
      $("#team-img-preview").src = dataUrl;
    } catch (e) { toast(e.message, true); }
  });
  $('[data-save="team"]').addEventListener("click", () => {
    working.team = { title: $("#team-title").value, img: $("#team-img-preview").src };
    persist("Photo d'équipe enregistrée !");
  });

  // --- Jeux ---
  function refreshGames() {
    renderImageListEditor("games-list", working.games, {
      imageKey: "img",
      textFields: [
        { key: "title", label: "Titre du jeu" },
        { key: "desc", label: "Description", multiline: true },
        { key: "link", label: "Lien (optionnel)" }
      ]
    });
  }
  $("#games-add").addEventListener("click", () => {
    working.games.push({ title: "Nouveau jeu", desc: "", img: "assets/img/logo.png", link: "" });
    refreshGames();
  });
  $('[data-save="games"]').addEventListener("click", () => persist("Jeux enregistrés !"));

  // --- Services ---
  function refreshServices() {
    renderImageListEditor("services-list", working.services, {
      imageKey: null,
      textFields: [
        { key: "icon", label: "Icône Font Awesome (ex: fa-gamepad)" },
        { key: "title", label: "Titre" },
        { key: "desc", label: "Description", multiline: true }
      ]
    });
  }
  $("#services-add").addEventListener("click", () => {
    working.services.push({ icon: "fa-star", title: "Nouveau service", desc: "" });
    refreshServices();
  });
  $('[data-save="services"]').addEventListener("click", () => persist("Services enregistrés !"));

  // --- Tarifs ---
  function refreshPrices() {
    const container = $("#prices-list");
    container.innerHTML = "";
    working.prices.forEach((item, index) => {
      const card = el("div", { class: "admin-card" }, "");
      card.style.gridTemplateColumns = "1fr auto";
      const fieldsWrap = el("div", { class: "admin-card-fields" });
      const nameInput = el("input", { type: "text", placeholder: "Nom de l'offre" }); nameInput.value = item.name || "";
      nameInput.addEventListener("input", () => item.name = nameInput.value);
      const priceInput = el("input", { type: "text", placeholder: "Prix (ex: 21$)" }); priceInput.value = item.price || "";
      priceInput.addEventListener("input", () => item.price = priceInput.value);
      const periodInput = el("input", { type: "text", placeholder: "Période (ex: /mois)" }); periodInput.value = item.period || "";
      periodInput.addEventListener("input", () => item.period = periodInput.value);
      const itemsInput = el("textarea", { rows: "4", placeholder: "Un avantage par ligne" }); itemsInput.value = (item.items || []).join("\n");
      itemsInput.addEventListener("input", () => item.items = itemsInput.value.split("\n").map(s => s.trim()).filter(Boolean));
      const featRow = el("label", { class: "admin-checkbox-row" });
      const featCb = el("input", { type: "checkbox" }); featCb.checked = !!item.featured;
      featCb.addEventListener("change", () => item.featured = featCb.checked);
      featRow.appendChild(featCb); featRow.appendChild(document.createTextNode("Mettre en avant (badge Populaire)"));
      [nameInput, priceInput, periodInput, itemsInput, featRow].forEach(n => fieldsWrap.appendChild(n));
      const removeBtn = el("button", { type: "button", class: "admin-card-remove" }, '<i class="fas fa-trash"></i>');
      removeBtn.addEventListener("click", () => { working.prices.splice(index, 1); refreshPrices(); });
      card.appendChild(fieldsWrap);
      card.appendChild(removeBtn);
      container.appendChild(card);
    });
    if (working.prices.length === 0) container.appendChild(el("p", { class: "admin-empty" }, "Aucune offre. Ajoutez-en une."));
  }
  $("#prices-add").addEventListener("click", () => {
    working.prices.push({ name: "Nouvelle offre", price: "0$", period: "/mois", items: [], featured: false });
    refreshPrices();
  });
  $('[data-save="prices"]').addEventListener("click", () => persist("Tarifs enregistrés !"));

  // --- FAQ ---
  function refreshFAQ() {
    const container = $("#faq-list");
    container.innerHTML = "";
    working.faq.forEach((item, index) => {
      const card = el("div", { class: "admin-card" });
      card.style.gridTemplateColumns = "1fr auto";
      const fieldsWrap = el("div", { class: "admin-card-fields" });
      const qInput = el("input", { type: "text", placeholder: "Question" }); qInput.value = item.q || "";
      qInput.addEventListener("input", () => item.q = qInput.value);
      const aInput = el("textarea", { rows: "3", placeholder: "Réponse" }); aInput.value = item.a || "";
      aInput.addEventListener("input", () => item.a = aInput.value);
      fieldsWrap.appendChild(qInput); fieldsWrap.appendChild(aInput);
      const removeBtn = el("button", { type: "button", class: "admin-card-remove" }, '<i class="fas fa-trash"></i>');
      removeBtn.addEventListener("click", () => { working.faq.splice(index, 1); refreshFAQ(); });
      card.appendChild(fieldsWrap);
      card.appendChild(removeBtn);
      container.appendChild(card);
    });
    if (working.faq.length === 0) container.appendChild(el("p", { class: "admin-empty" }, "Aucune question. Ajoutez-en une."));
  }
  $("#faq-add").addEventListener("click", () => {
    working.faq.push({ q: "Nouvelle question ?", a: "" });
    refreshFAQ();
  });
  $('[data-save="faq"]').addEventListener("click", () => persist("FAQ enregistrée !"));

  /* ============================ MESSAGES REÇUS ============================ */
  function renderRecords(containerId, storeKey, formatter) {
    const container = $("#" + containerId);
    container.innerHTML = "";
    let list = [];
    try { list = JSON.parse(localStorage.getItem(storeKey) || "[]"); } catch (e) { list = []; }
    if (list.length === 0) {
      container.appendChild(el("p", { class: "admin-empty" }, "Aucune donnée pour le moment."));
      return;
    }
    list.forEach((rec) => {
      const div = el("div", { class: "admin-record" });
      const date = rec.date ? new Date(rec.date).toLocaleString("fr-FR") : "";
      div.innerHTML = `<div class="rec-date">${esc(date)}</div>${formatter(rec)}`;
      container.appendChild(div);
    });
  }
  function loadMessages() {
    renderRecords("msg-contact", "eac_messages", (r) => `<strong>${esc(r.name)}</strong> (${esc(r.email)}) — ${esc(r.subject || "Sans sujet")}<br>${esc(r.message)}`);
    renderRecords("msg-meetings", "eac_meetings", (r) => `<strong>${esc(r.name)}</strong> — ${esc(r.email)} / ${esc(r.phone || "—")}${r.org ? " (organisation)" : ""}<br>${esc(r.message || "")}`);
    renderRecords("msg-leads", "eac_leads", (r) => `📧 ${esc(r.email)}`);
    renderRecords("msg-bookings", "eac_bookings", (r) => `<strong>${esc(r.plan)}</strong> — ${esc(r.price)}`);
  }
  $("#clear-messages").addEventListener("click", () => {
    if (!confirm("Supprimer définitivement tous les messages enregistrés ?")) return;
    ["eac_messages", "eac_meetings", "eac_leads", "eac_bookings"].forEach((k) => localStorage.removeItem(k));
    loadMessages();
    toast("Messages supprimés.");
  });

  /* ============================ SAUVEGARDE ============================ */
  $("#export-json").addEventListener("click", () => {
    const blob = new Blob([window.EAC_STORAGE.exportJSON()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = el("a", { href: url, download: "eac-contenu-" + Date.now() + ".json" });
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    toast("Export JSON téléchargé.");
  });
  $("#import-json-file").addEventListener("change", function () {
    const file = this.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast("Fichier trop volumineux (max 5 Mo).", true);
      this.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      let parsed;
      try { parsed = JSON.parse(reader.result); } catch (e) { parsed = null; }
      if (!parsed || typeof parsed !== "object") {
        toast("Fichier JSON invalide.", true);
        return;
      }
      // SÉCURITÉ : le JSON importé passe par le même filet de sécurité
      // (liens/images) que les modifications faites depuis les formulaires,
      // avant d'être appliqué et sauvegardé.
      working = parsed;
      sanitizeWorkingContent();
      const ok = window.EAC_STORAGE.setContent(working);
      if (ok) {
        toast("Import réussi ! Rechargement…");
        setTimeout(() => location.reload(), 800);
      } else {
        toast("Erreur lors de l'import (quota dépassé ?).", true);
      }
    };
    reader.onerror = () => toast("Impossible de lire le fichier.", true);
    reader.readAsText(file);
  });
  $("#reset-content").addEventListener("click", () => {
    if (!confirm("Réinitialiser tout le contenu personnalisé et revenir aux valeurs d'origine ?")) return;
    window.EAC_STORAGE.resetContent();
    toast("Contenu réinitialisé. Rechargement…");
    setTimeout(() => location.reload(), 800);
  });

  /* ============================ INIT ============================ */
  function init() {
    window.EAC_STORAGE.startAdminSession();
    loadGeneral();
    loadAccueil();
    refreshGallery();
    loadTeam();
    refreshGames();
    refreshServices();
    refreshPrices();
    refreshFAQ();
    loadMessages();
  }
  init();
})();
