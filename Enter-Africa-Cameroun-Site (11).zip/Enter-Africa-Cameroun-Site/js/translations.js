/**
 * ============================================================================
 *  EAC — TRADUCTIONS DU CONTENU DYNAMIQUE (EN / ES / DE)
 * ============================================================================
 *  Contrairement à js/i18n.js (textes fixes de l'interface : menus, titres de
 *  section...), ce fichier traduit le CONTENU (genèse, FAQ, services, tarifs,
 *  jeux, vision, carrousel...) chargé depuis content-default.js.
 *
 *  Les traductions ci-dessous ont été générées automatiquement puis relues ;
 *  il est recommandé de les faire valider par un locuteur natif avant une
 *  mise en production définitive (voir README.md).
 *
 *  Les noms propres (personnes, organisations, titres de jeux) ne sont pas
 *  traduits — seuls les libellés, descriptions et rôles génériques le sont.
 * ============================================================================
 */
(function (global) {
  "use strict";

  const TRANSLATIONS = {
    en: {
      site: { tagline: "Gamification, video game creation and digital training in Cameroon." },
      genese: {
        title: "EAC Genesis",
        html: "Project initiated by Goethe-Institut Addis Ababa (Ethiopia), notably Dr Julia SATTLER and Stefanie KASTNER from Goethe South Africa. <span>ENTER AFRICA</span> brings together 15 countries around the triptych: \"Past\", <span>Present</span> and \"Future\".<br><br>The idea is to use Gamification techniques and methods to re-create, showcase and project — through play — our <span>African</span> societies.<br><br>Through various levers including prototyping, design graphics &amp; other artistic or programming work (the \"Espoto\" software), drawn from traditional games, video, and more broadly the digital realm, we project ourselves digitally into a more balanced ecosystem.<br><br>In Cameroon, various personalities, skills (C. Deeg, D. Bedilu) and/or know-how brought these new local/intercultural bodies of knowledge to life.<br><br>Following this logic of knowledge transmission, the <span>EAC</span> project launched in June 2018 at the Goethe-Institut Kamerun.<br><br>By the end of that <span>Training</span>, about twenty mostly young Cameroonians managed to produce several digital games (Ongola Land, Voyageur) and one large analog game (Busara), together with the 14 other countries.<br><br>This \"Spectacular\" entry into the world of Gamification, Gaming, Virtual and Augmented Reality, Digital and Holographic technologies makes real a long-shared creative dream: the \"Transformation\" of our joint societies through Gamification and \"Play\". Benevolent progress, toward a certain \"Perfectibility\"."
      },
      presentationTitleHtml: "<span>EAC</span> / Ongola Land Presentation (2018-2019)",
      vision2030: {
        titleHtml: "Enter Africa Cameroon <span>_2030</span>",
        visionHtml: "Our goal is to train <span>3000 young</span> Africans and more by <span>2030</span> in digital, analog and video game creation, virtual reality and augmented reality.",
        visionHtml2: "And to make <span>EAC</span> a futuristic hub for development through new technologies.",
        process: [
          "Gamification",
          "Training",
          "Games-Jam / Parties",
          "Digital Workshops &amp; Refresher Courses",
          "Creating <span>12 games</span> by <span>2030</span>"
        ]
      },
      team: { title: "EAC Team / Game Launch 2019" },
      services: [
        { title: "Consulting", desc: "Analysis, game design, storytelling." },
        { title: "Training", desc: "Introduction to game design and programming." },
        { title: "Gamification", desc: "Game mechanics for your projects." },
        { title: "Support", desc: "Personalized guidance from A to Z." }
      ],
      prices: [
        { name: "Discovery Pass", period: "/month", items: ["Access to the Ongola Land demo", "Access to the EAC Discord server", "1 online workshop replay/month", "Digital community badge", "Newsletter: games & deals"] },
        { name: "Player Pass", period: "/month", items: ["Full Ongola Land + updates", "Digital Busara game kit", "Priority access to EAC betas", "1 online Game Night/month", "Discount on in-person workshops", "Priority email support"] },
        { name: "Creator Pass", period: "/month", items: ["All EAC games (Ongola Land, Busara, Voyageur)", "1 one-on-one mentoring session/month", "20% credit toward an EAC training", "Early access to new games", "Exclusive digital merch (wallpapers, badges)", "Priority support + creators community access"] }
      ],
      faq: [
        { q: "What is EAC?", a: "EAC is an association of video game and gamification enthusiasts based in Cameroon, training young people and creating African games." },
        { q: "What is your goal?", a: "Promoting African cultures through play, training people for digital careers, and building a video game ecosystem in Africa." },
        { q: "Where are you located?", a: "We are based at the Goethe-Institut in Yaoundé and work in collaboration with the Cameroonian Ministry of Culture." },
        { q: "Can I create my own game with you?", a: "Yes! We support you from concept to completion, through training and prototyping." }
      ],
      games: [
        { title: "Ongola Land", desc: "A digital game about the history of Cameroon." },
        { title: "Busara", desc: "A large strategic analog game." },
        { title: "Voyageur", desc: "A digital mini-game, Cameroon-Belgium." },
        { title: "Food-H", desc: "A mobile game raising awareness about food waste, by John Mbapou." },
        { title: "Other games", desc: "Discover our full collection." }
      ],
      capture: {
        title: "Get our free guide",
        desc: "The complete checklist of everything to verify before publishing a website — sign up with your email to receive it."
      },
      slider: [
        { desc: "The digital game Ongola Land, about the history of Cameroon" },
        { desc: "The board of the Busara analog game (EA)" },
        { desc: "ENTER AFRICA trainers, meeting at the Enter Africa booth" },
        { desc: "Goethe DG Fabian Mühlthaler hands out an award at the launch" },
        { desc: "Goethe Institut Kamerun mentors and EAC members, + our loyal audience" },
        { desc: "Graduation ceremony, EAC members" },
        { desc: "Members of the international Enter Africa team" },
        { desc: "Pousse Pions Festival — board games from Yaoundé" },
        { desc: "The ENTER AFRICA team at Gamescom 2019" },
        { desc: "A moment of exchange between EAC members and partners" },
        { desc: "The leadership team of the international Enter Africa network" },
        { desc: "Unveiling the Ongola Land game posters in Yaoundé" }
      ]
    },

    es: {
      site: { tagline: "Gamificación, creación de videojuegos y formación digital en Camerún." },
      genese: {
        title: "Génesis de EAC",
        html: "Proyecto iniciado por el Goethe-Institut Addis Abeba (Etiopía), en particular la Dra. Julia SATTLER y Stefanie KASTNER del Goethe Sudáfrica. <span>ENTER AFRICA</span> reúne a 15 países en torno al tríptico: «Pasado», <span>Presente</span> y «Futuro».<br><br>Se trata de utilizar las técnicas y métodos de la Gamificación para recrear, valorizar y proyectar, a través del juego, nuestras sociedades <span>africanas</span>.<br><br>Mediante diversas palancas como el prototipado, el diseño gráfico &amp; otros trabajos artísticos o de programación (el software «Espoto»), inspirados en los juegos tradicionales, el video y, en definitiva, lo digital, nos proyectamos hacia un ecosistema más equilibrado.<br><br>En Camerún, distintas personalidades, competencias (C. Deeg, D. Bedilu) y/o saberes hicieron posible dar vida a estos nuevos conocimientos locales/interculturales.<br><br>Siguiendo esta lógica de transmisión de saberes, el proyecto <span>EAC</span> se lanzó en junio de 2018 en el Goethe-Institut Kamerun.<br><br>Al final de dicha <span>Formación</span>, una veintena de camerुneses·as, en su mayoría jóvenes, lograron producir varios juegos digitales (Ongola Land, Voyageur) y un gran juego analógico (Busara), junto con los otros 14 países.<br><br>Esta entrada «espectacular» en el mundo de la Ludificación, el Gaming, lo Virtual, la Realidad Aumentada, lo Digital y lo Holográfico concreta un viejo sueño creativo compartido: la «Transformación» de nuestras sociedades conjuntas mediante la Gamificación y el «Juego». Un progreso benévolo hacia una cierta «Perfectibilidad»."
      },
      presentationTitleHtml: "Presentación <span>EAC</span> / Ongola Land (2018-2019)",
      vision2030: {
        titleHtml: "Enter Africa Camerún <span>_2030</span>",
        visionHtml: "Nuestro objetivo es formar a <span>3000 jóvenes</span> africanos o más de aquí a <span>2030</span> en los oficios digitales, los juegos analógicos y de video, la realidad virtual y la realidad aumentada.",
        visionHtml2: "Y hacer de <span>EAC</span> un polo futurista de desarrollo a través de las nuevas tecnologías.",
        process: [
          "Gamificación",
          "Formación",
          "Games-Jam / Fiestas",
          "Talleres y reciclajes digitales",
          "Creación de <span>12 juegos</span> de aquí a <span>2030</span>"
        ]
      },
      team: { title: "Equipo EAC / Lanzamiento del juego 2019" },
      services: [
        { title: "Consultoría", desc: "Análisis, diseño de juegos, narrativa." },
        { title: "Formación", desc: "Iniciación al diseño de juegos y la programación." },
        { title: "Gamificación", desc: "Mecánicas de juego para sus proyectos." },
        { title: "Acompañamiento", desc: "Seguimiento personalizado de principio a fin." }
      ],
      prices: [
        { name: "Pase Descubrimiento", period: "/mes", items: ["Acceso a la demo de Ongola Land", "Acceso al servidor Discord de EAC", "1 repetición de taller online/mes", "Insignia de comunidad digital", "Newsletter: juegos y ofertas"] },
        { name: "Pase Jugador", period: "/mes", items: ["Ongola Land completo + actualizaciones", "Kit digital del juego Busara", "Acceso prioritario a las betas de EAC", "1 Game Night online/mes", "Descuento en talleres presenciales", "Soporte prioritario por email"] },
        { name: "Pase Creador", period: "/mes", items: ["Todos los juegos EAC (Ongola Land, Busara, Voyageur)", "1 sesión de mentoría individual/mes", "20% de crédito para una formación EAC", "Acceso anticipado a nuevos juegos", "Merch digital exclusivo (fondos, insignias)", "Soporte prioritario + comunidad de creadores"] }
      ],
      faq: [
        { q: "¿Qué es EAC?", a: "EAC es una asociación de apasionados de los videojuegos y la gamificación, con sede en Camerún, que forma a los jóvenes y crea juegos africanos." },
        { q: "¿Cuál es su objetivo?", a: "Promover las culturas africanas a través del juego, formar en oficios digitales y crear un ecosistema de videojuegos en África." },
        { q: "¿Dónde están ubicados?", a: "Estamos en el Goethe-Institut de Yaundé y trabajamos en colaboración con el Ministerio de Cultura de Camerún." },
        { q: "¿Puedo crear mi propio juego con ustedes?", a: "¡Sí! Le acompañamos desde la concepción hasta la realización, pasando por la formación y el prototipado." }
      ],
      games: [
        { title: "Ongola Land", desc: "Juego digital sobre la historia de Camerún." },
        { title: "Busara", desc: "Gran juego analógico estratégico." },
        { title: "Voyageur", desc: "Minijuego digital Camerún-Bélgica." },
        { title: "Food-H", desc: "Juego móvil de concientización sobre el desperdicio de alimentos, por John Mbapou." },
        { title: "Otros juegos", desc: "Descubra nuestra colección completa." }
      ],
      capture: {
        title: "Reciba nuestra guía gratuita",
        desc: "La checklist completa de los elementos a verificar antes de publicar un sitio web — regístrese con su email para recibirla."
      },
      slider: [
        { desc: "El juego digital Ongola Land, sobre la historia de Camerún" },
        { desc: "El tablero del juego analógico Busara (EA)" },
        { desc: "Formadores de ENTER AFRICA, encuentro en el stand Enter Africa" },
        { desc: "El DG de Goethe, Fabian Mühlthaler, entrega un premio en el lanzamiento" },
        { desc: "Instructores del Goethe Institut Kamerun y miembros de EAC, + nuestro fiel público" },
        { desc: "Ceremonia de graduación, miembros de EAC" },
        { desc: "Miembros del equipo internacional Enter Africa" },
        { desc: "Festival Pousse Pions — juegos de mesa de Yaundé" },
        { desc: "El equipo ENTER AFRICA en la Gamescom 2019" },
        { desc: "Un momento de intercambio entre miembros y socios de EAC" },
        { desc: "El equipo directivo de la red internacional Enter Africa" },
        { desc: "Presentación de los carteles del juego Ongola Land en Yaundé" }
      ]
    },

    de: {
      site: { tagline: "Gamification, Videospielentwicklung und digitale Weiterbildung in Kamerun." },
      genese: {
        title: "Entstehung von EAC",
        html: "Projekt initiiert vom Goethe-Institut Addis Abeba (Äthiopien), insbesondere von Dr. Julia SATTLER und Stefanie KASTNER vom Goethe-Institut Südafrika. <span>ENTER AFRICA</span> vereint 15 Länder rund um das Triptychon: „Vergangenheit“, <span>Gegenwart</span> und „Zukunft“.<br><br>Ziel ist es, mit den Techniken und Methoden der Gamification unsere <span>afrikanischen</span> Gesellschaften spielerisch neu zu erschaffen, aufzuwerten und zu projizieren.<br><br>Über verschiedene Hebel wie Prototyping, Konzeptgrafik &amp; weitere künstlerische oder Programmierarbeiten (die Software „Espoto“), inspiriert von traditionellen Spielen, Video und ganz allgemein dem Digitalen, projizieren wir uns digital in ein ausgewogeneres Ökosystem.<br><br>In Kamerun haben verschiedene Persönlichkeiten, Kompetenzen (C. Deeg, D. Bedilu) und/oder Know-how dazu beigetragen, diesem neuen lokalen/interkulturellen Wissen Leben einzuhauchen.<br><br>Dieser Logik der Wissensvermittlung folgend, wurde das <span>EAC</span>-Projekt im Juni 2018 am Goethe-Institut Kamerun gestartet.<br><br>Am Ende dieser <span>Ausbildung</span> gelang es rund zwanzig, eher jungen Kamerunerinnen und Kamerunern, gemeinsam mit den 14 anderen Ländern einige digitale Spiele (Ongola Land, Voyageur) sowie ein großes analoges Spiel (Busara) zu entwickeln.<br><br>Dieser „spektakuläre“ Einstieg in die Welt der Gamification, des Gamings, von Virtual und Augmented Reality, des Digitalen und Holografischen macht einen lange geteilten kreativen Traum greifbar: die „Transformation“ unserer gemeinsamen Gesellschaften durch Gamification und „Spiel“. Wohlwollender Fortschritt hin zu einer gewissen „Perfektibilität“."
      },
      presentationTitleHtml: "<span>EAC</span> / Ongola Land Präsentation (2018-2019)",
      vision2030: {
        titleHtml: "Enter Africa Kamerun <span>_2030</span>",
        visionHtml: "Unser Ziel ist es, bis <span>2030</span> <span>3000 junge</span> Afrikanerinnen und Afrikaner und mehr in digitalen Berufen, analogen und Videospielen, virtueller und erweiterter Realität auszubilden.",
        visionHtml2: "Und <span>EAC</span> zu einem futuristischen Entwicklungszentrum durch neue Technologien zu machen.",
        process: [
          "Gamification",
          "Ausbildung",
          "Games-Jam / Partys",
          "Digitale Workshops und Auffrischungskurse",
          "Erstellung von <span>12 Spielen</span> bis <span>2030</span>"
        ]
      },
      team: { title: "EAC-Team / Spiele-Launch 2019" },
      services: [
        { title: "Beratung", desc: "Analyse, Game Design, Erzählstruktur." },
        { title: "Ausbildung", desc: "Einführung in Game Design und Programmierung." },
        { title: "Gamification", desc: "Spielmechaniken für Ihre Projekte." },
        { title: "Begleitung", desc: "Persönliche Betreuung von A bis Z." }
      ],
      prices: [
        { name: "Entdecker-Pass", period: "/Monat", items: ["Zugang zur Ongola-Land-Demo", "Zugang zum EAC-Discord-Server", "1 Workshop-Aufzeichnung/Monat", "Digitales Community-Abzeichen", "Newsletter: Spiele & Angebote"] },
        { name: "Spieler-Pass", period: "/Monat", items: ["Ongola Land vollständig + Updates", "Digitales Busara-Spielkit", "Prioritärer Zugang zu EAC-Betas", "1 Online-Game-Night/Monat", "Rabatt auf Präsenz-Workshops", "Bevorzugter E-Mail-Support"] },
        { name: "Kreativ-Pass", period: "/Monat", items: ["Alle EAC-Spiele (Ongola Land, Busara, Voyageur)", "1 Einzel-Mentoring-Sitzung/Monat", "20% Gutschrift für eine EAC-Ausbildung", "Früher Zugang zu neuen Spielen", "Exklusives digitales Merch (Wallpaper, Abzeichen)", "Prioritärer Support + Creator-Community"] }
      ],
      faq: [
        { q: "Was ist EAC?", a: "EAC ist ein Verein von Videospiel- und Gamification-Enthusiasten mit Sitz in Kamerun, der junge Menschen ausbildet und afrikanische Spiele entwickelt." },
        { q: "Was ist Ihr Ziel?", a: "Afrikanische Kulturen durch Spiele fördern, für digitale Berufe ausbilden und ein Videospiel-Ökosystem in Afrika aufbauen." },
        { q: "Wo befinden Sie sich?", a: "Wir sind am Goethe-Institut Jaunde ansässig und arbeiten mit dem kamerunischen Kulturministerium zusammen." },
        { q: "Kann ich mit Ihnen mein eigenes Spiel entwickeln?", a: "Ja! Wir begleiten Sie von der Konzeption bis zur Umsetzung, inklusive Ausbildung und Prototyping." }
      ],
      games: [
        { title: "Ongola Land", desc: "Digitales Spiel über die Geschichte Kameruns." },
        { title: "Busara", desc: "Großes strategisches analoges Spiel." },
        { title: "Voyageur", desc: "Digitales Minispiel Kamerun-Belgien." },
        { title: "Food-H", desc: "Ein mobiles Spiel zur Sensibilisierung für Lebensmittelverschwendung, von John Mbapou." },
        { title: "Weitere Spiele", desc: "Entdecken Sie unsere vollständige Sammlung." }
      ],
      capture: {
        title: "Erhalten Sie unseren kostenlosen Leitfaden",
        desc: "Die vollständige Checkliste aller Punkte, die vor der Veröffentlichung einer Website geprüft werden sollten — melden Sie sich mit Ihrer E-Mail an, um sie zu erhalten."
      },
      slider: [
        { desc: "Das digitale Spiel Ongola Land über die Geschichte Kameruns" },
        { desc: "Das Spielbrett des analogen Spiels Busara (EA)" },
        { desc: "ENTER AFRICA Trainer, Treffen am Enter-Africa-Stand" },
        { desc: "Goethe-DG Fabian Mühlthaler überreicht einen Preis beim Launch" },
        { desc: "Betreuer des Goethe Institut Kamerun und EAC-Mitglieder, + unser treues Publikum" },
        { desc: "Abschlusszeremonie, EAC-Mitglieder" },
        { desc: "Mitglieder des internationalen Enter-Africa-Teams" },
        { desc: "Festival Pousse Pions — Brettspiele aus Jaunde" },
        { desc: "Das ENTER AFRICA Team auf der Gamescom 2019" },
        { desc: "Ein Austauschmoment zwischen EAC-Mitgliedern und Partnern" },
        { desc: "Das Leitungsteam des internationalen Enter-Africa-Netzwerks" },
        { desc: "Enthüllung der Ongola-Land-Spielplakate in Jaunde" }
      ]
    }
  };

  /** Fusionne récursivement en respectant l'ordre des tableaux (fusion positionnelle,
   *  utile ici car les traductions gardent le même ordre que le contenu FR de base). */
  function mergeTranslation(base, override) {
    if (Array.isArray(base) && Array.isArray(override)) {
      return base.map((item, i) => (override[i] !== undefined ? mergeTranslation(item, override[i]) : item));
    }
    if (base && override && typeof base === "object" && typeof override === "object" && !Array.isArray(base)) {
      const out = Object.assign({}, base);
      Object.keys(override).forEach((k) => { out[k] = mergeTranslation(base[k], override[k]); });
      return out;
    }
    return override !== undefined ? override : base;
  }

  /** Retourne le contenu traduit pour la langue donnée (fr = contenu de base, inchangé). */
  function translate(baseContent, lang) {
    if (!lang || lang === "fr" || !TRANSLATIONS[lang]) return baseContent;
    return mergeTranslation(baseContent, TRANSLATIONS[lang]);
  }

  global.EAC_TRANSLATE = translate;
})(window);
