/**
 * ============================================================================
 *  EAC — COMMON.JS — Logique partagée entre toutes les pages
 * ============================================================================
 *  Utilisé par index.html, games.html, services.html et contact.html.
 *  Gère : en-tête (menu, thème, langue, recherche), pied de page, chatbot,
 *  bouton flottant, indicateur de scroll, traduction, et utilitaires communs
 *  (toast, stockage local des formulaires, lecteur YouTube "lite").
 * ============================================================================
 */
(function () {
  "use strict";

  const esc = window.EAC_STORAGE.escapeHTML;
  const content = window.EAC_STORAGE.getContent();

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }

  function el(tag, attrs, html) {
    const node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach((k) => {
        if (k === "class") node.className = attrs[k];
        else if (k === "dataset") Object.assign(node.dataset, attrs[k]);
        else node.setAttribute(k, attrs[k]);
      });
    }
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function isExternal(link) {
    return typeof link === "string" && /^https?:\/\//i.test(link);
  }

  function safeLink(link, fallback) {
    if (!link || link.trim() === "") return fallback || "#";
    if (!window.EAC_STORAGE.isSafeUrl(link)) {
      console.warn("Lien ignoré (schéma non autorisé) :", link);
      return fallback || "#";
    }
    return link;
  }

  function safeImg(src) {
    if (!src || !window.EAC_STORAGE.isSafeImageSrc(src)) return "assets/img/logo.png";
    return src;
  }

  /* ============================ TOASTS ============================ */
  function toast(message, type) {
    const container = $("#toastContainer");
    if (!container) return;
    const t = el("div", { class: "toast" }, esc(message));
    if (type === "error") t.style.borderColor = "var(--color-tertiary)";
    container.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = "opacity .4s"; }, 3200);
    setTimeout(() => t.remove(), 3700);
  }

  /* ============================ MINI "BACKEND" LOCAL ============================ */
  function pushRecord(storeKey, record) {
    try {
      const raw = localStorage.getItem(storeKey);
      const list = raw ? JSON.parse(raw) : [];
      list.unshift(Object.assign({ date: new Date().toISOString() }, record));
      localStorage.setItem(storeKey, JSON.stringify(list.slice(0, 200)));
      return true;
    } catch (e) {
      console.error("Erreur d'enregistrement local", e);
      return false;
    }
  }

  /* ============================ LECTEUR YOUTUBE "LITE" ============================ */
  function buildYoutubeEmbed(youtubeId, poster, alt) {
    const wrap = el("div", { class: "yt-embed", tabindex: "0", role: "button", "aria-label": "Lire la vidéo : " + (alt || "") });
    const img = el("img", { src: safeImg(poster), alt: esc(alt || ""), loading: "lazy" });
    img.onerror = function () { this.src = "assets/img/logo.png"; };
    wrap.appendChild(img);
    wrap.appendChild(el("div", { class: "yt-play-btn" }, '<i class="fas fa-play" aria-hidden="true"></i>'));
    function play() { openVideoModal(youtubeId, alt); }
    wrap.addEventListener("click", play);
    wrap.addEventListener("keypress", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); play(); } });
    return wrap;
  }

  /* ============================ EFFET MACHINE À ÉCRIRE ============================
     Anime le texte d'un élément caractère par caractère (en conservant les
     <span> de mise en couleur existants), avec un petit curseur clignotant.
     N'altère pas le HTML source au-delà d'un seul niveau de <span> imbriqué,
     ce qui correspond à l'usage du site (titres avec quelques mots colorés).
  ============================================================================= */
  function typewriterEffect(target, speed) {
    if (!target) return;
    const sourceHTML = target.innerHTML;
    const parser = document.createElement("div");
    parser.innerHTML = sourceHTML;
    const tokens = [];
    parser.childNodes.forEach((node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        node.textContent.split("").forEach((ch) => tokens.push({ ch, span: null }));
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const span = { tag: node.tagName.toLowerCase(), cls: node.className || "" };
        Array.from(node.textContent).forEach((ch) => tokens.push({ ch, span }));
      }
    });
    if (tokens.length === 0) return;
    target.innerHTML = "";
    target.classList.add("typewriter-active");
    let i = 0;
    let lastKey = undefined;
    let currentSpanEl = null;
    function tick() {
      if (i >= tokens.length) {
        target.classList.remove("typewriter-active");
        return;
      }
      const t = tokens[i];
      const key = t.span ? t.span.tag + "|" + t.span.cls : null;
      if (key !== lastKey) {
        if (t.span) {
          currentSpanEl = document.createElement(t.span.tag);
          if (t.span.cls) currentSpanEl.className = t.span.cls;
          target.appendChild(currentSpanEl);
        } else {
          currentSpanEl = null;
        }
        lastKey = key;
      }
      const textNode = document.createTextNode(t.ch);
      if (currentSpanEl) currentSpanEl.appendChild(textNode);
      else target.appendChild(textNode);
      i++;
      setTimeout(tick, speed || 45);
    }
    tick();
  }

  /* ============================ MODAL VIDÉO (lecture sans quitter le site) ============================
     Ouvre un lecteur YouTube "lite" dans une fenêtre modale par-dessus la page
     courante. La vidéo se joue jusqu'à l'arrêt ou la fin sans navigation hors
     du site, contrairement à un lien classique vers youtube.com.
  ============================================================================= */
  let modalEl = null;
  function ensureVideoModal() {
    if (modalEl) return modalEl;
    modalEl = el("div", { class: "video-modal", role: "dialog", "aria-modal": "true", "aria-hidden": "true", "aria-label": "Lecteur vidéo" });
    modalEl.innerHTML = `
      <div class="video-modal-backdrop"></div>
      <div class="video-modal-box">
        <button class="video-modal-close" aria-label="Fermer la vidéo"><i class="fas fa-times" aria-hidden="true"></i></button>
        <div class="video-modal-player"></div>
      </div>`;
    document.body.appendChild(modalEl);
    const close = () => closeVideoModal();
    modalEl.querySelector(".video-modal-backdrop").addEventListener("click", close);
    modalEl.querySelector(".video-modal-close").addEventListener("click", close);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && modalEl.classList.contains("open")) close(); });
    return modalEl;
  }
  function closeVideoModal() {
    if (!modalEl) return;
    modalEl.classList.remove("open");
    modalEl.setAttribute("aria-hidden", "true");
    // Vide le lecteur pour couper immédiatement le son/la lecture
    modalEl.querySelector(".video-modal-player").innerHTML = "";
    document.body.classList.remove("modal-open");
  }
  function openVideoModal(youtubeId, title) {
    const modal = ensureVideoModal();
    const player = modal.querySelector(".video-modal-player");
    player.innerHTML = "";
    const iframe = el("iframe", {
      src: `https://www.youtube-nocookie.com/embed/${encodeURIComponent(youtubeId)}?autoplay=1&rel=0`,
      title: title || "Vidéo EAC",
      frameborder: "0",
      allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
      allowfullscreen: "allowfullscreen"
    });
    player.appendChild(iframe);
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    modal.querySelector(".video-modal-close").focus();
  }

  /** Extrait l'identifiant YouTube d'une URL complète (youtu.be/... ou
   *  youtube.com/watch?v=...) ou retourne la valeur telle quelle si c'est
   *  déjà un identifiant brut. */
  function extractYoutubeId(value) {
    if (!value) return "";
    const v = String(value).trim();
    const shortMatch = v.match(/youtu\.be\/([a-zA-Z0-9_-]{6,})/);
    if (shortMatch) return shortMatch[1];
    const longMatch = v.match(/[?&]v=([a-zA-Z0-9_-]{6,})/);
    if (longMatch) return longMatch[1];
    const embedMatch = v.match(/embed\/([a-zA-Z0-9_-]{6,})/);
    if (embedMatch) return embedMatch[1];
    return v.replace(/[^a-zA-Z0-9_-]/g, "");
  }

  /* ============================ MODAL DE CONTENU GÉNÉRIQUE (RGPD, SAV…) ============================
     Réutilise la même mécanique que la modal vidéo (overlay, fermeture par
     croix / clic hors zone / touche Échap) mais pour afficher du texte
     (politique de confidentialité, SAV...) sans quitter le site.
  ============================================================================= */
  let contentModalEl = null;
  function ensureContentModal() {
    if (contentModalEl) return contentModalEl;
    contentModalEl = el("div", { class: "content-modal", role: "dialog", "aria-modal": "true", "aria-hidden": "true" });
    contentModalEl.innerHTML = `
      <div class="content-modal-backdrop"></div>
      <div class="content-modal-box">
        <button class="content-modal-close" aria-label="Fermer"><i class="fas fa-times" aria-hidden="true"></i></button>
        <h2 class="content-modal-title"></h2>
        <div class="content-modal-body"></div>
      </div>`;
    document.body.appendChild(contentModalEl);
    const close = () => closeContentModal();
    contentModalEl.querySelector(".content-modal-backdrop").addEventListener("click", close);
    contentModalEl.querySelector(".content-modal-close").addEventListener("click", close);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && contentModalEl.classList.contains("open")) close(); });
    return contentModalEl;
  }
  function closeContentModal() {
    if (!contentModalEl) return;
    contentModalEl.classList.remove("open");
    contentModalEl.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  }
  function openContentModal(title, html) {
    const modal = ensureContentModal();
    modal.querySelector(".content-modal-title").textContent = title || "";
    // Le HTML provient uniquement de content-default.js / du panneau admin
    // (contenu de confiance, jamais de saisie utilisateur brute) — cohérent
    // avec le traitement de genese.html ailleurs sur le site.
    modal.querySelector(".content-modal-body").innerHTML = html || "<p>Contenu à venir.</p>";
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    modal.querySelector(".content-modal-close").focus();
  }

  /**
   * Joue l'animation machine à écrire d'ouverture, commune à toutes les
   * pages : d'abord le menu (Accueil Services Jeux Contact), puis le titre
   * principal, puis — uniquement si présent sur la page (accueil) — le
   * texte de bienvenue et le lien "ICI". Le rythme est volontairement lent
   * et posé. Ne se rejoue pas au changement de langue.
   */
  function playIntroTypewriter(titleSelector) {
    const MENU_SPEED = 28;
    const TITLE_SPEED = 60;
    const WELCOME_SPEED = 58;
    const ICI_SPEED = 70;

    let delay = 150;
    const menuLinks = $all(".Menu a");
    menuLinks.forEach((a) => {
      const text = a.textContent || "";
      setTimeout(() => typewriterEffect(a, MENU_SPEED), delay);
      delay += text.length * MENU_SPEED + 160;
    });

    delay += 250; // pause avant le titre
    const titleEl = $(titleSelector);
    if (titleEl) {
      const titleDelay = delay;
      setTimeout(() => typewriterEffect(titleEl, TITLE_SPEED), titleDelay);
      delay += (titleEl.textContent || "").length * TITLE_SPEED + 400;
    }

    const welcomeEl = $("#welcome-typewriter");
    const iciEl = $("#hero-ici-link");
    if (welcomeEl) {
      const welcomeDelay = delay;
      setTimeout(() => typewriterEffect(welcomeEl, WELCOME_SPEED), welcomeDelay);
      delay += (welcomeEl.textContent || "").length * WELCOME_SPEED + 350;
      if (iciEl) {
        const iciDelay = delay;
        setTimeout(() => typewriterEffect(iciEl, ICI_SPEED), iciDelay);
      }
    }
  }

  /* ============================ SCROLL WATCHER ============================ */
  function initScrollWatcher() {
    const watcher = $("#scrollWatcher");
    if (!watcher) return;
    function update() {
      const scrollY = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      const progress = height > 0 ? scrollY / height : 0;
      watcher.style.transform = `scaleX(${Math.min(Math.max(progress, 0), 1)})`;
    }
    window.addEventListener("scroll", update, { passive: true });
    update();
  }

  /* ============================ MENU HAMBURGER + ACTIVE LINK ============================ */
  function initMenu() {
    const hamburgerBtn = $("#hamburgerBtn");
    const mainMenu = $("#mainMenu");
    if (!hamburgerBtn || !mainMenu) return;
    hamburgerBtn.addEventListener("click", () => {
      const isOpen = mainMenu.classList.toggle("open");
      hamburgerBtn.setAttribute("aria-expanded", String(isOpen));
      hamburgerBtn.innerHTML = isOpen ? '<i class="fas fa-times" aria-hidden="true"></i>' : '<i class="fas fa-bars" aria-hidden="true"></i>';
    });
    $all(".Menu a").forEach((a) => a.addEventListener("click", () => {
      mainMenu.classList.remove("open");
      hamburgerBtn.setAttribute("aria-expanded", "false");
      hamburgerBtn.innerHTML = '<i class="fas fa-bars" aria-hidden="true"></i>';
    }));

    // Marque le lien de la page courante comme actif (comparaison sur le nom de fichier)
    const currentPage = (location.pathname.split("/").pop() || "index.html") || "index.html";
    $all(".Menu a").forEach((a) => {
      const href = a.getAttribute("href") || "";
      const hrefPage = href.split("#")[0] || "index.html";
      if (hrefPage === currentPage || (currentPage === "" && hrefPage === "index.html")) {
        a.classList.add("active");
      }
    });

    // Sur la page d'accueil : surligne la section visible au scroll
    const sections = $all("main section[id]");
    if (sections.length) {
      const menuLinks = $all(".Menu a");
      const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            menuLinks.forEach((a) => {
              const href = a.getAttribute("href") || "";
              if (href.indexOf("#" + id) !== -1) a.classList.add("active");
              else if (href.indexOf("#") !== -1) a.classList.remove("active");
            });
          }
        });
      }, { rootMargin: "-40% 0px -50% 0px" });
      sections.forEach((s) => sectionObserver.observe(s));
    }
  }

  /* ============================ THEME TOGGLE ============================ */
  function initTheme() {
    const themeToggle = $("#themeToggle");
    if (!themeToggle) return;
    const currentTheme = localStorage.getItem("eac-theme") || "dark";
    document.documentElement.setAttribute("data-theme", currentTheme);
    function paintIcon(theme) {
      themeToggle.innerHTML = theme === "dark" ? '<i class="fas fa-moon" aria-hidden="true"></i>' : '<i class="fas fa-sun" aria-hidden="true"></i>';
    }
    paintIcon(currentTheme);
    themeToggle.addEventListener("click", () => {
      const theme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", theme);
      localStorage.setItem("eac-theme", theme);
      paintIcon(theme);
    });
  }

  /* ============================ LANGUE (traduction complète au clic) ============================
     applyLanguage() traduit :
     - Les textes fixes de l'interface (data-i18n / data-i18n-html) via js/i18n.js
     - Le contenu dynamique de la page courante, en ré-exécutant sa fonction de
       rendu (enregistrée via EAC_COMMON.onLanguageChange) avec les traductions
       de js/translations.js pour la langue choisie.
  ============================================================================= */
  const languageChangeCallbacks = [];
  function onLanguageChange(fn) { languageChangeCallbacks.push(fn); }

  function applyLanguage(lang) {
    const dict = (window.EAC_I18N && window.EAC_I18N[lang]) || (window.EAC_I18N && window.EAC_I18N.fr) || {};
    $all("[data-i18n]").forEach((node) => {
      const key = node.getAttribute("data-i18n");
      if (dict[key] !== undefined) node.innerHTML = dict[key];
    });
    $all("[data-i18n-html]").forEach((node) => {
      const key = node.getAttribute("data-i18n-html");
      if (dict[key] !== undefined) node.innerHTML = dict[key];
    });
    const chatWelcome = $("#chatMessages .bot");
    if (chatWelcome && dict.chat_welcome) chatWelcome.textContent = dict.chat_welcome;
    document.documentElement.setAttribute("lang", lang);
    // Ré-exécute les rendus dynamiques de la page courante dans la nouvelle langue
    languageChangeCallbacks.forEach((fn) => { try { fn(lang); } catch (e) { console.error(e); } });
  }

  function initLanguage() {
    const langSelect = $("#langSelect");
    if (!langSelect) return null;
    const savedLang = localStorage.getItem("eac-lang") || "fr";
    langSelect.value = savedLang;
    langSelect.addEventListener("change", function () {
      localStorage.setItem("eac-lang", this.value);
      applyLanguage(this.value);
    });
    return savedLang;
  }

  /* ============================ RECHERCHE (index global multi-pages) ============================ */
  function buildSearchIndex() {
    const idx = [];
    (content.games || []).forEach((g) => idx.push({ title: g.title, type: "jeu", url: "games.html", excerpt: g.desc }));
    (content.services || []).forEach((s) => idx.push({ title: s.title, type: "service", url: "services.html", excerpt: s.desc }));
    (content.faq || []).forEach((f) => idx.push({ title: f.q, type: "faq", url: "services.html#faq", excerpt: f.a }));
    (content.gallery || []).forEach((p) => idx.push({ title: p.title, type: "équipe/galerie", url: "index.html#home", excerpt: "" }));
    (content.externalResources || []).forEach((r) => idx.push({ title: r.name, type: "ressource externe", url: r.url, excerpt: r.desc }));
    (content.searchExtra || []).forEach((e) => idx.push(e));
    return idx;
  }

  function initSearch() {
    const searchIndex = buildSearchIndex();
    const searchInput = $("#live-search");
    const resultsBox = $("#search-results");
    const searchForm = $("#searchForm");
    if (!searchInput || !resultsBox || !searchForm) return;
    let searchDebounce;

    // Bouton "effacer" qui apparaît dès qu'il y a du texte
    const clearBtn = el("button", { type: "button", class: "search-clear", "aria-label": "Effacer la recherche" }, '<i class="fas fa-times" aria-hidden="true"></i>');
    clearBtn.style.display = "none";
    searchInput.insertAdjacentElement("afterend", clearBtn);
    clearBtn.addEventListener("click", () => {
      searchInput.value = "";
      resultsBox.classList.remove("active");
      resultsBox.innerHTML = "";
      clearBtn.style.display = "none";
      searchInput.focus();
    });

    function runSearch(query) {
      const q = query.trim().toLowerCase();
      clearBtn.style.display = query.length > 0 ? "flex" : "none";
      if (q.length < 2) { resultsBox.classList.remove("active"); resultsBox.innerHTML = ""; return; }
      resultsBox.innerHTML = '<div class="loading">Recherche…</div>';
      resultsBox.classList.add("active");
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(() => {
        const filtered = searchIndex.filter((item) =>
          item.title.toLowerCase().includes(q) ||
          (item.type || "").toLowerCase().includes(q) ||
          (item.excerpt || "").toLowerCase().includes(q)
        ).slice(0, 12);
        if (filtered.length > 0) {
          const ul = el("ul");
          filtered.forEach((item) => {
            const li = el("li");
            const href = window.EAC_STORAGE.isSafeUrl(item.url) ? item.url : "#";
            const targetAttr = isExternal(href) ? ' target="_blank" rel="noopener noreferrer"' : "";
            li.innerHTML = `<a href="${esc(href)}"${targetAttr}><strong>${esc(item.title)}</strong> <span class="type">(${esc(item.type)})</span><br><small>${esc(item.excerpt || "")}</small></a>`;
            ul.appendChild(li);
          });
          resultsBox.innerHTML = "";
          resultsBox.appendChild(ul);
        } else {
          resultsBox.innerHTML = '<p class="no-results">Aucun résultat trouvé</p>';
        }
      }, 250);
    }
    searchInput.addEventListener("input", () => runSearch(searchInput.value));
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { resultsBox.classList.remove("active"); searchInput.blur(); }
    });
    searchForm.addEventListener("submit", (e) => { e.preventDefault(); runSearch(searchInput.value); });
    document.addEventListener("click", (e) => { if (!e.target.closest(".search-bar")) resultsBox.classList.remove("active"); });
  }

  /* ============================ ANIMATIONS AU SCROLL ============================ */
  function initScrollAnimations() {
    $all(".service-card, .game-card, .Team, .Pup-form, .price-card, .gallery-card, .video-card, .activity-card, .carousel-card, .team-mini-card").forEach((elm) => elm.classList.add("animate-on-scroll"));
    $all(".text-video, .Vision-30, .img-EAC-Team_Pup-form, .genese-wrapper, .contact-section").forEach((elm) => elm.classList.add("fade-in"));
    const animEls = $all(".fade-in, .animate-on-scroll");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add("visible"); });
    }, { threshold: 0.12 });
    animEls.forEach((elm) => observer.observe(elm));
  }

  /* ============================ FLOATING CONTACT ============================ */
  function initFloatingContact() {
    const floatingBtn = $("#floatingContact");
    const footer = $("#mainFooter");
    if (!floatingBtn || !footer) return;
    floatingBtn.addEventListener("click", () => {
      const contactSection = $("#contact");
      if (contactSection) contactSection.scrollIntoView({ behavior: "smooth" });
      else window.location.href = "contact.html";
    });
    const footerBtn = $("#footerContactBtn");
    if (footerBtn) footerBtn.addEventListener("click", () => {
      const contactSection = $("#contact");
      if (contactSection) contactSection.scrollIntoView({ behavior: "smooth" });
      else window.location.href = "contact.html";
    });
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((entry) => floatingBtn.classList.toggle("hidden", entry.isIntersecting));
    }, { threshold: 0.1 });
    obs.observe(footer);
  }

  /* ============================ CHATBOT ============================ */
  function initChatbot() {
    const chatToggle = $("#chatToggle");
    const chatWindow = $("#chatWindow");
    const closeChat = $("#closeChat");
    const chatMessages = $("#chatMessages");
    const chatInput = $("#chatInput");
    const sendChat = $("#sendChat");
    if (!chatToggle || !chatWindow) return;

    chatToggle.addEventListener("click", () => {
      const active = chatWindow.classList.toggle("active");
      chatToggle.setAttribute("aria-expanded", String(active));
      chatWindow.setAttribute("aria-hidden", String(!active));
      if (active) chatInput.focus();
    });
    closeChat.addEventListener("click", () => {
      chatWindow.classList.remove("active");
      chatToggle.setAttribute("aria-expanded", "false");
      chatWindow.setAttribute("aria-hidden", "true");
    });

    function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

    const QUICK_REPLIES = [
      { label: "Nos jeux", msg: "Quels sont vos jeux ?" },
      { label: "Nos tarifs", msg: "Quels sont vos tarifs ?" },
      { label: "Nous contacter", msg: "Comment vous contacter ?" },
      { label: "RGPD / SAV", msg: "rgpd" }
    ];

    function getBotResponse(msg) {
      const lower = msg.toLowerCase();
      if (/(bonjour|salut|hello|hola|hallo|coucou)/.test(lower)) {
        return pick([
          "Bonjour ! Je suis l'assistant EAC. Je vous informe sur le jeu vidéo local, africain et mondial. Posez-moi vos questions !",
          "Salut ! Ravi de vous accueillir sur le site d'Enter Africa Cameroun. Que puis-je faire pour vous ?"
        ]);
      } else if (/(eac|enter africa)/.test(lower)) {
        return "EAC (Enter Africa Cameroun) est un projet de gamification et de création de jeux vidéo basé au Cameroun, soutenu par le Goethe-Institut. Nous formons les jeunes aux métiers du numérique et créons des jeux inspirés des cultures africaines.";
      } else if (/(rgpd|confidentialité|confidentialite|données|donnees|privacy)/.test(lower)) {
        setTimeout(() => openContentModal("Politique de confidentialité (RGPD)", content.site.rgpdContent), 400);
        return "Voici notre politique de confidentialité (RGPD), elle s'ouvre dans une fenêtre juste ici.";
      } else if (/(sav|service après.vente|après.vente|apres.vente)/.test(lower)) {
        setTimeout(() => openContentModal("Service après-vente (SAV)", content.site.savContent), 400);
        return "J'ouvre pour vous les informations du service après-vente (SAV).";
      } else if (/(jeu|game|spiel|juego)/.test(lower)) {
        return "Le jeu vidéo est un secteur en pleine croissance en Afrique. Au Cameroun, EAC produit des jeux comme Ongola Land (histoire du Cameroun) et Busara (stratégie). Retrouvez-les tous sur la page Jeux.";
      } else if (/(afrique|cameroun)/.test(lower)) {
        return "L'Afrique compte une scène de jeu vidéo dynamique : Kiro'o Games et Maliyo Games au Nigeria, Sea Monster et Nyamakop en Afrique du Sud, Usiku Games au Kenya, et EAC au Cameroun.";
      } else if (/(formation|cours|training|ausbildung|apprendre)/.test(lower)) {
        return "Nous proposons des formations en game design, programmation et gamification pour tous les niveaux. Consultez la page Services pour en savoir plus.";
      } else if (/(contact|email|joindre|appel|téléphone|telephone)/.test(lower)) {
        return `Vous pouvez nous contacter via le formulaire de la page Contact ou par email à ${content.site.email}. Nous vous répondrons rapidement.`;
      } else if (/(prix|tarif|price|preis|combien|coûte|coute)/.test(lower)) {
        return "Nos tarifs sont disponibles sur la page Services : offres Starter, Advanced et Premium.";
      } else if (/(mondial|international|global)/.test(lower)) {
        return "Le jeu vidéo mondial pèse plus de 200 milliards de dollars. L'Afrique représente encore une petite part mais connaît une croissance rapide.";
      } else if (/(local|camerounais)/.test(lower)) {
        return "Au Cameroun, le jeu vidéo est encore émergent mais prometteur. EAC en est l'un des principaux acteurs, avec Ongola Land et Busara.";
      } else if (/(vidéo|video|youtube|regarder)/.test(lower)) {
        return "Vous trouverez nos vidéos directement sur le site : dans la galerie de l'accueil et sur la page Jeux. Elles se lisent sans quitter le site !";
      } else if (/(équipe|equipe|qui êtes|qui etes|membres)/.test(lower)) {
        return "Notre équipe réunit une trentaine de membres passionnés — game designers, formateurs, artistes et bénévoles. Retrouvez leurs portraits dans la galerie de l'accueil.";
      } else if (/(aide|help|assistance)/.test(lower)) {
        return "Je peux vous renseigner sur EAC, nos jeux, nos formations, nos tarifs, notre RGPD/SAV ou l'actualité du jeu vidéo. Vous pouvez aussi utiliser la barre de recherche en haut du site.";
      } else if (/(au revoir|bye|adios|tschüss|ciao)/.test(lower)) {
        return pick(["Au revoir, et à bientôt sur EAC !", "À bientôt ! N'hésitez pas à revenir si vous avez d'autres questions."]);
      } else if (/(merci|thanks|danke|gracias)/.test(lower)) {
        return pick(["Avec plaisir ! N'hésitez pas si vous avez d'autres questions.", "Je vous en prie ! Bonne visite sur le site EAC."]);
      }
      return "Je ne suis pas sûr de bien comprendre. Je peux vous parler d'EAC, du jeu vidéo en Afrique, de nos formations, de nos jeux, de nos tarifs, de notre équipe, ou de l'actualité mondiale du jeu vidéo. Pour une question précise, notre équipe humaine reste disponible via la page Contact.";
    }

    function addMessage(sender, text) {
      const div = el("div", { class: sender }, esc(text));
      chatMessages.appendChild(div);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    function showTyping() {
      const typing = el("div", { class: "typing-indicator", id: "typingIndicator" }, "L'assistant réfléchit…");
      chatMessages.appendChild(typing);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    function removeTyping() { const t = $("#typingIndicator"); if (t) t.remove(); }
    function handleSend(customText) {
      const text = (customText !== undefined ? customText : chatInput.value).trim();
      if (!text) return;
      addMessage("user", text);
      chatInput.value = "";
      showTyping();
      const delay = 700 + Math.random() * 900;
      setTimeout(() => { removeTyping(); addMessage("bot", getBotResponse(text)); }, delay);
    }

    // Suggestions rapides : cliquer envoie directement le message associé
    const quickRepliesEl = $("#chatQuickReplies");
    if (quickRepliesEl) {
      QUICK_REPLIES.forEach((qr) => {
        const btn = el("button", { type: "button" }, esc(qr.label));
        btn.addEventListener("click", () => handleSend(qr.msg));
        quickRepliesEl.appendChild(btn);
      });
    }
    sendChat.addEventListener("click", () => handleSend());
    chatInput.addEventListener("keypress", (e) => { if (e.key === "Enter") handleSend(); });
  }

  /* ============================ FOOTER (rendu commun à toutes les pages) ============================ */
  function socialIcons(social) {
    const wrap = document.createDocumentFragment();
    const icons = { facebook: "fa-facebook-f", linkedin: "fa-linkedin-in", youtube: "fa-youtube" };
    Object.keys(icons).forEach((key) => {
      const url = safeLink(social && social[key], "#");
      const a = el("a", { href: url, "aria-label": key.charAt(0).toUpperCase() + key.slice(1) });
      if (isExternal(url)) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener noreferrer"); }
      a.innerHTML = `<i class="fab ${icons[key]}" aria-hidden="true"></i>`;
      wrap.appendChild(a);
    });
    return wrap;
  }

  function renderFooter() {
    const site = content.site || {};
    const brand = $("#footer-brand"); if (brand) brand.textContent = site.shortName || "EAC";
    const year = $("#footer-year"); if (year) year.textContent = new Date().getFullYear();
    const desc = $("#footer-desc"); if (desc) desc.textContent = site.tagline || "";
    const socialsEl = $("#footer-socials"); if (socialsEl) socialsEl.appendChild(socialIcons(site.social));

    const logo = $("#site-logo"); if (logo) { logo.src = safeImg(site.logo); logo.onerror = function () { this.src = "assets/img/logo.png"; }; }

    $all("#link-rgpd").forEach((a) => a.addEventListener("click", (e) => {
      e.preventDefault();
      openContentModal("Politique de confidentialité (RGPD)", site.rgpdContent);
    }));
    $all("#link-sav").forEach((a) => a.addEventListener("click", (e) => {
      e.preventDefault();
      openContentModal("Service après-vente (SAV)", site.savContent);
    }));
    $all("#link-partners").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); toast("Page Partenaires à venir."); }));

    // Lien admin : invisible pour les visiteurs normaux. Ne devient un lien
    // "Se déconnecter" fonctionnel que dans le navigateur ayant déjà ouvert
    // le panneau d'administration (voir SECURITY.md / .env.example).
    const adminSlot = $("#admin-session-link");
    if (adminSlot) {
      adminSlot.innerHTML = "";
      if (window.EAC_STORAGE.isAdminSession()) {
        const logout = el("a", { href: "#", class: "admin-link" }, '<i class="fas fa-right-from-bracket" aria-hidden="true"></i> Se déconnecter');
        logout.addEventListener("click", (e) => {
          e.preventDefault();
          window.EAC_STORAGE.endAdminSession();
          toast("Déconnecté de l'espace administration.");
          adminSlot.innerHTML = "";
        });
        adminSlot.appendChild(logout);
      }
    }
  }

  /* ============================ INIT COMMUN ============================ */
  function initCommon() {
    initScrollWatcher();
    initMenu();
    initTheme();
    const savedLang = initLanguage() || localStorage.getItem("eac-lang") || "fr";
    initSearch();
    initFloatingContact();
    initChatbot();
    renderFooter();
    return savedLang;
  }

  window.EAC_COMMON = {
    esc, content, $, $all, el, isExternal, safeLink, safeImg,
    toast, pushRecord, buildYoutubeEmbed,
    typewriterEffect, playIntroTypewriter, openVideoModal, closeVideoModal, extractYoutubeId,
    openContentModal, closeContentModal,
    applyLanguage, onLanguageChange, initCommon, initScrollAnimations,
    socialIcons
  };
})();
