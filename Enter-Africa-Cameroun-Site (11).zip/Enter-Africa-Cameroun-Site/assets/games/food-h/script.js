// Game State Management
        class GameState {
            constructor() {
                this.currentScreen = 'mainMenu';
                this.gameMode = 'solo'; // 'solo' or 'multiplayer'
                this.environment = 'home';
                this.level = 1;
                this.score = 0;
                this.lives = 3;
                this.maxLives = 3;
                this.foodCaught = 0;
                this.foodMissed = 0;
                this.combo = 0;
                this.maxCombo = 0;
                this.isPaused = false;
                this.isGameActive = false;
                this.currentPlayer = 1;
                this.totalPlayers = 2;
                this.playerScores = [0, 0];
                this.playerStats = [{}, {}];

                // Env icon movement
                this.envIconPosition = { x: 0 };
                this.envIconSpeed = 5;
                this.isMovingLeft = false;
                this.isMovingRight = false;
                this.isDragging = false;
                this.dragStart = { x: 0, y: 0 };

                // Food items
                this.foods = [];
                this.foodSpawnRate = 2000;
                this.foodSpeed = 2;

                // Game timers
                this.gameLoop = null;
                this.foodSpawner = null;
                this.comboTimer = null;

                this.loadStats();
                this.initializeAchievements();
            }

            loadStats() {
                try {
                    const saved = localStorage.getItem('foodHStats');
                    if (saved) {
                        const stats = JSON.parse(saved);
                        this.totalFoodSaved = stats.totalFoodSaved || 0;
                        this.bestScore = stats.bestScore || 0;
                        this.levelsCompleted = stats.levelsCompleted || 0;
                        this.humanitarianSends = stats.humanitarianSends || 0;
                        this.unlockedAchievements = stats.unlockedAchievements || [];
                    } else {
                        this.totalFoodSaved = 0;
                        this.bestScore = 0;
                        this.levelsCompleted = 0;
                        this.humanitarianSends = 0;
                        this.unlockedAchievements = [];
                    }
                    this.updateDailyStats();
                } catch (e) {
                    console.warn('Failed to load stats:', e);
                    this.totalFoodSaved = 0;
                    this.bestScore = 0;
                    this.levelsCompleted = 0;
                    this.humanitarianSends = 0;
                    this.unlockedAchievements = [];
                    this.updateDailyStats();
                }
            }

            saveStats() {
                try {
                    const stats = {
                        totalFoodSaved: this.totalFoodSaved,
                        bestScore: this.bestScore,
                        levelsCompleted: this.levelsCompleted,
                        humanitarianSends: this.humanitarianSends,
                        unlockedAchievements: this.unlockedAchievements,
                        lastPlayed: new Date().toDateString()
                    };
                    localStorage.setItem('foodHStats', JSON.stringify(stats));
                } catch (e) {
                    console.warn('Failed to save stats:', e);
                }
            }

            updateDailyStats() {
                const dailyKey = `dailyStats_${new Date().toDateString()}`;
                try {
                    const daily = localStorage.getItem(dailyKey);
                    this.dailySaved = daily ? parseInt(daily) : 0;
                } catch (e) {
                    this.dailySaved = 0;
                }
                const dailySavedElement = document.getElementById('dailySaved');
                if (dailySavedElement) {
                    dailySavedElement.textContent = this.dailySaved;
                }
            }

            addDailyStats(amount) {
                this.dailySaved += amount;
                const dailyKey = `dailyStats_${new Date().toDateString()}`;
                try {
                    localStorage.setItem(dailyKey, this.dailySaved.toString());
                } catch (e) {
                    console.warn('Failed to save daily stats:', e);
                }
                const dailySavedElement = document.getElementById('dailySaved');
                if (dailySavedElement) {
                    dailySavedElement.textContent = this.dailySaved;
                }
            }

            initializeAchievements() {
                this.achievements = [
                    {
                        id: 'first_catch',
                        name: 'Premier Sauvetage',
                        description: 'Attrapez votre premier aliment',
                        icon: '🍎'
                    },
                    {
                        id: 'combo_master',
                        name: 'Maître du Combo',
                        description: 'Réalisez un combo de 5',
                        icon: '⚡'
                    },
                    {
                        id: 'life_saver',
                        name: 'Sauveur de Vies',
                        description: 'Sauvez 50 aliments',
                        icon: '❤️'
                    },
                    {
                        id: 'humanitarian',
                        name: 'Humanitaire',
                        description: 'Effectuez 10 envois humanitaires',
                        icon: '📦'
                    },
                    {
                        id: 'perfectionist',
                        name: 'Perfectionniste',
                        description: 'Terminez un niveau sans perdre de vie',
                        icon: '🏆'
                    },
                    {
                        id: 'environment_explorer',
                        name: 'Explorateur',
                        description: 'Jouez dans tous les environnements',
                        icon: '🌍'
                    }
                ];
            }

            checkAchievements() {
                const newAchievements = [];

                // First catch
                if (this.foodCaught >= 1 && !this.unlockedAchievements.includes('first_catch')) {
                    newAchievements.push('first_catch');
                }

                // Combo master
                if (this.maxCombo >= 5 && !this.unlockedAchievements.includes('combo_master')) {
                    newAchievements.push('combo_master');
                }

                // Life saver
                if (this.totalFoodSaved >= 50 && !this.unlockedAchievements.includes('life_saver')) {
                    newAchievements.push('life_saver');
                }

                // Humanitarian
                if (this.humanitarianSends >= 10 && !this.unlockedAchievements.includes('humanitarian')) {
                    newAchievements.push('humanitarian');
                }

                newAchievements.forEach(id => {
                    this.unlockedAchievements.push(id);
                    this.showAchievementUnlock(id);
                });

                if (newAchievements.length > 0) {
                    this.saveStats();
                }
            }

            showAchievementUnlock(achievementId) {
                const achievement = this.achievements.find(a => a.id === achievementId);
                if (achievement) {
                    showNotification(`${achievement.icon} ${achievement.name} débloqué!`, 'achievement');
                }
            }
        }

        // Environment Configurations
        const ENVIRONMENTS = {
            home: {
                name: 'Maison',
                goodFoods: ['🍎', '🍌', '🥕', '🥦', '🍅', '🥔'],
                badFoods: ['🍕', '🍔', '🍟'],
                spawnRate: 2500,
                speed: 1.5,
                special: null,
                color: '#fbbf24',
                bgPattern: 'url(\'image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect x="10" y="10" width="2" height="2" fill="%23f97316" opacity="0.1"/></svg>\')'
            },
            beach: {
                name: 'Plage',
                goodFoods: ['🍉', '🍍', '🥥', '🥭', '🍊', '🍋'],
                badFoods: ['🥤', '🍦', '🍬'],
                spawnRate: 2000,
                speed: 2,
                special: 'wind',
                color: '#0ea5e9',
                bgPattern: 'url(\'image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="1" fill="%230ea5e9" opacity="0.2"/><circle cx="80" cy="40" r="1.5" fill="%230ea5e9" opacity="0.1"/></svg>\')'
            },
            restaurant: {
                name: 'Restaurant',
                goodFoods: ['🥗', '🍲', '🥖', '🥚', '🥑', '🥙'],
                badFoods: ['🌭', '🧂', '🍩'],
                spawnRate: 1500,
                speed: 2.5,
                special: 'fast',
                color: '#ef4444',
                bgPattern: 'url(\'image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="2" fill="%23ef4444" opacity="0.1"/></svg>\')'
            },
            gym: {
                name: 'Salle de sport',
                goodFoods: ['🥜', '🥚', '🍞', '🥙', '🥛', '🍎'],
                badFoods: ['🍫', '🍭', '🍪'],
                spawnRate: 1800,
                speed: 3,
                special: 'bouncy',
                color: '#8b5cf6',
                bgPattern: 'url(\'image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><polygon points="50,10 60,30 40,30" fill="%238b5cf6" opacity="0.1"/></svg>\')'
            }
        };

        // Bonus items
        const BONUS_ITEMS = [
            { symbol: '❤️', type: 'life', value: 1, color: '#f59e0b' },
            { symbol: '⭐', type: 'score', value: 100, color: '#fbbf24' },
            { symbol: '🛡️', type: 'shield', value: 5000, color: '#3b82f6' },
            { symbol: '⚡', type: 'speed', value: 3000, color: '#8b5cf6' }
        ];

        // Crisis regions for humanitarian distribution
        const CRISIS_REGIONS = [
            'l\'Afrique de l\'Est',
            'le Sahel',
            'Haïti',
            'le Yémen',
            'l\'Afghanistan',
            'le Soudan',
            'le Bangladesh',
            'le Venezuela'
        ];

        // Global Game Instance
        let gameState = new GameState();

        // Utility Functions
        function getRandomGoodFood(environment) {
            const foods = ENVIRONMENTS[environment].goodFoods;
            return foods[Math.floor(Math.random() * foods.length)];
        }

        function getRandomBadFood(environment) {
            const foods = ENVIRONMENTS[environment].badFoods;
            return foods[Math.floor(Math.random() * foods.length)];
        }

        function getRandomBonus() {
            return BONUS_ITEMS[Math.floor(Math.random() * BONUS_ITEMS.length)];
        }

        function getRandomPosition() {
            return Math.random() * (window.innerWidth - 80) + 40;
        }

        function distance(p1, p2) {
            return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
        }

        // Audio Management
        class AudioManager {
            constructor() {
                this.sounds = {
                    catch: document.getElementById('catchSound'),
                    miss: document.getElementById('missSound'),
                    bonus: document.getElementById('bonusSound'),
                    levelComplete: document.getElementById('levelCompleteSound')
                };
                this.isMuted = false;
                this.currentSound = null;
            }

            play(soundName) {
                if (!this.isMuted && this.sounds[soundName]) {
                    this.sounds[soundName].currentTime = 0;
                    this.sounds[soundName].play().catch(() => {
                        // Ignore audio play errors (autoplay policy)
                    });
                }
            }

            toggleMute() {
                this.isMuted = !this.isMuted;
            }
        }

        const audioManager = new AudioManager();

        // Screen Management
        function showScreen(screenId) {
            document.querySelectorAll('.screen').forEach(screen => {
                screen.classList.remove('active');
            });
            const screen = document.getElementById(screenId);
            if (screen) {
                screen.classList.add('active');
                gameState.currentScreen = screenId;
            }
        }

        function showMainMenu() {
            showScreen('mainMenu');
            gameState.isGameActive = false;
            clearGameTimers();
            updateStatsDisplay();
        }

        function showInstructions() {
            showScreen('instructionsScreen');
        }

        function showStats() {
            updateStatsDisplay();
            updateAchievementsDisplay();
            showScreen('statsScreen');
        }

        function updateStatsDisplay() {
            const totalFoodSaved = document.getElementById('totalFoodSaved');
            const bestScore = document.getElementById('bestScore');
            const levelsCompleted = document.getElementById('levelsCompleted');
            const humanitarianSends = document.getElementById('humanitarianSends');

            if (totalFoodSaved) totalFoodSaved.textContent = gameState.totalFoodSaved;
            if (bestScore) bestScore.textContent = gameState.bestScore;
            if (levelsCompleted) levelsCompleted.textContent = gameState.levelsCompleted;
            if (humanitarianSends) humanitarianSends.textContent = gameState.humanitarianSends;
        }

        function updateAchievementsDisplay() {
            const container = document.getElementById('achievementList');
            if (!container) return;

            container.innerHTML = '';
            gameState.achievements.forEach(achievement => {
                const div = document.createElement('div');
                div.className = `achievement-item ${gameState.unlockedAchievements.includes(achievement.id) ? 'unlocked' : ''}`;
                div.innerHTML = `
                    <span>${achievement.icon}</span>
                    <div>
                        <strong>${achievement.name}</strong>
                        <br><small>${achievement.description}</small>
                    </div>
                `;
                container.appendChild(div);
            });
        }

        // Game Initialization
        function startGame(mode) {
            gameState.gameMode = mode;
            if (mode === 'multiplayer') {
                gameState.totalPlayers = 2;
                gameState.currentPlayer = 1;
                gameState.playerScores = [0, 0];
            }
            showScreen('environmentScreen');
        }

        function selectEnvironment(env) {
            gameState.environment = env;
            initializeGame();
        }

        function initializeGame() {
            gameState.level = 1;
            gameState.score = 0;
            gameState.lives = 3;
            gameState.maxLives = 3;
            gameState.foodCaught = 0;
            gameState.foodMissed = 0;
            gameState.combo = 0;
            gameState.maxCombo = 0;
            gameState.foods = [];
            gameState.isGameActive = true;
            gameState.isPaused = false;

            if (gameState.gameMode === 'multiplayer') {
                gameState.currentPlayer = 1;
            }

            setupGameEnvironment();
            showScreen('gameScreen');
            startGameLoop();
        }

        function setupGameEnvironment() {
            const bg = document.getElementById('environmentBg');
            if (bg) {
                bg.className = `environment-bg env-${gameState.environment}`;
            }

            const envConfig = ENVIRONMENTS[gameState.environment];
            gameState.foodSpawnRate = envConfig.spawnRate;
            gameState.foodSpeed = envConfig.speed;

            updateGameUI();
            resetEnvIconPosition();
        }

        function updateGameUI() {
            const scoreElement = document.getElementById('score');
            const levelElement = document.getElementById('level');
            const livesElement = document.getElementById('lives');
            const currentPlayerElement = document.getElementById('currentPlayer');
            const playerTurnElement = document.getElementById('playerTurn');

            if (scoreElement) scoreElement.textContent = gameState.score;
            if (levelElement) levelElement.textContent = gameState.level;
            if (livesElement) livesElement.textContent = '❤ '.repeat(gameState.lives).trim();
            if (gameState.gameMode === 'multiplayer') {
                if (playerTurnElement) playerTurnElement.style.display = 'block';
                if (currentPlayerElement) currentPlayerElement.textContent = gameState.currentPlayer;
            } else {
                if (playerTurnElement) playerTurnElement.style.display = 'none';
            }

            updateComboDisplay();
        }

        function updateComboDisplay() {
            const comboCounter = document.getElementById('comboCounter');
            const comboValue = document.getElementById('comboValue');

            if (gameState.combo > 1) {
                if (comboCounter) comboCounter.style.display = 'block';
                if (comboValue) comboValue.textContent = gameState.combo;
            } else {
                if (comboCounter) comboCounter.style.display = 'none';
            }

            // Visual feedback for combo
            if (gameState.combo >= 3) {
                const envIconContainer = document.getElementById('envIconContainer');
                if (envIconContainer) {
                    envIconContainer.style.animation = 'pulse 0.5s ease-in-out infinite';
                }
            } else {
                const envIconContainer = document.getElementById('envIconContainer');
                if (envIconContainer) {
                    envIconContainer.style.animation = '';
                }
            }
        }

        function resetEnvIconPosition() {
            const envIconContainer = document.getElementById('envIconContainer');
            const gameArea = document.getElementById('gameArea');
            if (!envIconContainer || !gameArea) return;

            const rect = gameArea.getBoundingClientRect();
            gameState.envIconPosition.x = rect.width / 2;
            envIconContainer.style.left = `${gameState.envIconPosition.x}px`;
            envIconContainer.style.bottom = '120px';
            envIconContainer.style.transform = 'translateX(-50%)';
        }

        // Env Icon Control System
        function initializeEnvIconControls() {
            // Keyboard controls
            document.addEventListener('keydown', handleKeyDown, { passive: false });
            document.addEventListener('keyup', handleKeyUp, { passive: false });

            // Mouse controls
            document.addEventListener('mousedown', handleMouseDown, { passive: false });
            document.addEventListener('mousemove', handleMouseMove, { passive: false });
            document.addEventListener('mouseup', handleMouseUp, { passive: false });

            // Touch controls for mobile
            const gameArea = document.getElementById('gameArea');
            if (gameArea) {
                gameArea.addEventListener('touchstart', handleTouchStart, { passive: false });
                gameArea.addEventListener('touchmove', handleTouchMove, { passive: false });
                gameArea.addEventListener('touchend', handleTouchEnd, { passive: false });
            }
        }

        function handleKeyDown(e) {
            if (!gameState.isGameActive || gameState.isPaused) return;

            switch (e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    gameState.isMovingLeft = true;
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    gameState.isMovingRight = true;
                    break;
            }
        }

        function handleKeyUp(e) {
            switch (e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    gameState.isMovingLeft = false;
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    gameState.isMovingRight = false;
                    break;
            }
        }

        function handleMouseDown(e) {
            if (!gameState.isGameActive || gameState.isPaused) return;
            e.preventDefault();
            gameState.isDragging = true;
            gameState.dragStart.x = e.clientX;
            gameState.dragStart.y = e.clientY;
            
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.classList.add('dragging');
            }
        }

        function handleMouseMove(e) {
            if (!gameState.isGameActive || gameState.isPaused || !gameState.isDragging) return;
            e.preventDefault();

            const gameArea = document.getElementById('gameArea');
            if (!gameArea) return;

            const rect = gameArea.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const plateWidth = 80;

            gameState.envIconPosition.x = Math.max(plateWidth / 2, Math.min(rect.width - plateWidth / 2, x));
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.style.left = `${gameState.envIconPosition.x}px`;
            }
        }

        function handleMouseUp() {
            gameState.isDragging = false;
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.classList.remove('dragging');
            }
        }

        function handleTouchStart(e) {
            if (!gameState.isGameActive || gameState.isPaused) return;
            e.preventDefault();
            gameState.isDragging = true;
            const touch = e.touches[0];
            gameState.dragStart.x = touch.clientX;
            gameState.dragStart.y = touch.clientY;
            
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.classList.add('dragging');
            }
        }

        function handleTouchMove(e) {
            if (!gameState.isGameActive || gameState.isPaused || !gameState.isDragging) return;
            e.preventDefault();
            
            const touch = e.touches[0];
            const gameArea = document.getElementById('gameArea');
            if (!gameArea) return;

            const rect = gameArea.getBoundingClientRect();
            const x = touch.clientX - rect.left;
            const plateWidth = 80;

            gameState.envIconPosition.x = Math.max(plateWidth / 2, Math.min(rect.width - plateWidth / 2, x));
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.style.left = `${gameState.envIconPosition.x}px`;
            }
        }

        function handleTouchEnd() {
            gameState.isDragging = false;
            const envIconContainer = document.getElementById('envIconContainer');
            if (envIconContainer) {
                envIconContainer.classList.remove('dragging');
            }
        }

        function updateEnvIconPosition() {
            if (!gameState.isGameActive || gameState.isPaused || gameState.isDragging) return;

            const envIconContainer = document.getElementById('envIconContainer');
            const gameArea = document.getElementById('gameArea');
            if (!envIconContainer || !gameArea) return;

            const rect = gameArea.getBoundingClientRect();
            const iconRect = envIconContainer.getBoundingClientRect();

            // Adjust env icon speed based on level and environment
            const baseSpeed = 5;
            const levelMultiplier = 1 + (gameState.level - 1) * 0.2;
            const envMultiplier = ENVIRONMENTS[gameState.environment].speed / 2;
            gameState.envIconSpeed = baseSpeed * levelMultiplier * envMultiplier;

            // Move env icon based on input
            if (gameState.isMovingLeft) {
                gameState.envIconPosition.x = Math.max(iconRect.width / 2, gameState.envIconPosition.x - gameState.envIconSpeed);
            }
            if (gameState.isMovingRight) {
                gameState.envIconPosition.x = Math.min(rect.width - iconRect.width / 2, gameState.envIconPosition.x + gameState.envIconSpeed);
            }

            // Update env icon position
            envIconContainer.style.left = `${gameState.envIconPosition.x}px`;
        }

        // Food Management
        function spawnFood() {
            if (!gameState.isGameActive || gameState.isPaused) return;

            const foodContainer = document.getElementById('foodContainer');
            if (!foodContainer) return;

            // Determine if this is a bonus item (less frequent)
            const isBonus = Math.random() < 0.05 && gameState.level >= 3;
            const isBadFood = Math.random() < 0.3 + (gameState.level - 1) * 0.1;

            const food = document.createElement('div');
            food.className = 'food-item';
            
            let foodData = {
                x: getRandomPosition(),
                y: 0,
                caught: false,
                element: food
            };

            if (isBonus) {
                const bonus = getRandomBonus();
                food.textContent = bonus.symbol;
                food.classList.add('bonus');
                foodData.type = 'bonus';
                foodData.bonusType = bonus.type;
                foodData.value = bonus.value;
                foodData.color = bonus.color;
                food.style.color = bonus.color;
            } else if (isBadFood) {
                food.textContent = getRandomBadFood(gameState.environment);
                food.classList.add('bad');
                foodData.type = 'bad';
                foodData.value = 15;
            } else {
                food.textContent = getRandomGoodFood(gameState.environment);
                food.classList.add('good');
                foodData.type = 'good';
                foodData.value = 10 + Math.floor(Math.random() * 15);
            }

            // Set speed based on level and environment
            foodData.speed = gameState.foodSpeed + Math.random() * 1;
            if (foodData.type === 'bonus') {
                foodData.speed *= 0.8; // Bonus items fall slower
            }

            // Apply special environment effects
            const envConfig = ENVIRONMENTS[gameState.environment];
            if (envConfig.special === 'wind') {
                foodData.drift = (Math.random() - 0.5) * 2;
            } else if (envConfig.special === 'bouncy') {
                foodData.bounce = true;
                foodData.bouncePhase = Math.random() * Math.PI * 2;
            }

            // Position the food
            food.style.left = `${foodData.x}px`;
            food.style.top = '0px';

            // Add glow effect based on type with reduced shadow
            if (foodData.type === 'good') {
                food.style.textShadow = '0 0 4px rgba(34, 197, 94, 0.4)';
            } else if (foodData.type === 'bad') {
                food.style.textShadow = '0 0 4px rgba(239, 68, 68, 0.4)';
            } else if (foodData.type === 'bonus') {
                food.style.textShadow = `0 0 4px ${foodData.color}`;
            }

            gameState.foods.push(foodData);
            foodContainer.appendChild(food);

            // Schedule next spawn with difficulty progression
            const baseSpawnRate = ENVIRONMENTS[gameState.environment].spawnRate;
            const difficultyFactor = 1 - (gameState.level - 1) * 0.1;
            const adjustedSpawnRate = Math.max(800, baseSpawnRate * difficultyFactor);
            gameState.foodSpawnRate = adjustedSpawnRate;
            
            const nextSpawn = adjustedSpawnRate + Math.random() * 1000 - 500;
            gameState.foodSpawner = setTimeout(spawnFood, Math.max(500, nextSpawn));
        }

        function updateFoodPositions() {
            const gameArea = document.getElementById('gameArea');
            if (!gameArea) return;

            const gameRect = gameArea.getBoundingClientRect();

            gameState.foods.forEach((food, index) => {
                if (food.caught) return;

                // Update position based on environment
                food.y += food.speed;

                // Apply special effects
                const envConfig = ENVIRONMENTS[gameState.environment];
                if (envConfig.special === 'wind' && food.drift !== undefined) {
                    food.x += food.drift;
                } else if (envConfig.special === 'bouncy' && food.bounce) {
                    food.x += Math.sin(food.bouncePhase + food.y * 0.01) * 0.5;
                }

                // Update DOM position
                food.element.style.left = `${food.x}px`;
                food.element.style.top = `${food.y}px`;

                // Check if food hit the ground
                if (food.y > gameRect.height - 160) {
                    foodMissed(index);
                }
            });

            // Remove foods that are off-screen or caught
            gameState.foods = gameState.foods.filter(food => {
                if (food.caught || food.y > gameRect.height) {
                    if (food.element.parentNode) {
                        food.element.parentNode.removeChild(food.element);
                    }
                    return false;
                }
                return true;
            });
        }

        function checkFoodCollisions() {
            const envIconContainer = document.getElementById('envIconContainer');
            if (!envIconContainer) return;

            const iconRect = envIconContainer.getBoundingClientRect();
            const iconCenter = {
                x: iconRect.left + iconRect.width / 2,
                y: iconRect.top + iconRect.height / 2
            };

            const collisionRadius = 60;

            gameState.foods.forEach((food, index) => {
                if (food.caught) return;

                const foodCenter = {
                    x: food.x,
                    y: food.y
                };

                const dist = distance(iconCenter, foodCenter);

                if (dist < collisionRadius) {
                    foodCaught(index);
                }
            });
        }

        function foodCaught(index) {
            const food = gameState.foods[index];
            if (!food || food.caught) return;

            food.caught = true;
            food.element.classList.add('caught');
            food.element.classList.add('collected');

            // Update game state based on food type
            if (food.type === 'good') {
                // Good food - increase score and combo
                gameState.score += food.value * (1 + gameState.combo * 0.1);
                gameState.foodCaught++;
                gameState.combo++;
                gameState.maxCombo = Math.max(gameState.maxCombo, gameState.combo);
                gameState.totalFoodSaved++;
                audioManager.play('catch');
                showScorePopup(food.x, food.y, '+' + Math.round(food.value * (1 + (gameState.combo - 1) * 0.1)));
                
                // Check for level completion
                if (gameState.foodCaught >= 10 + gameState.level * 5) {
                    completeLevel();
                }
            } else if (food.type === 'bad') {
                // Bad food - decrease lives, reset combo
                gameState.combo = 0;
                gameState.lives--;
                audioManager.play('miss');
                showScorePopup(food.x, food.y, '-1 vie', '#ef4444');
                
                if (gameState.lives <= 0) {
                    gameOver();
                }
            } else if (food.type === 'bonus') {
                // Bonus item - special effects
                audioManager.play('bonus');
                showScorePopup(food.x, food.y, getBonusText(food), '#fbbf24');
                
                switch (food.bonusType) {
                    case 'life':
                        gameState.lives = Math.min(5, gameState.lives + food.value);
                        break;
                    case 'score':
                        gameState.score += food.value;
                        break;
                    case 'shield':
                        // Implement temporary shield (visual effect only for now)
                        const envIcon = document.querySelector('.env-icon');
                        envIcon.style.filter = 'drop-shadow(0 0 4px #3b82f6)';
                        setTimeout(() => {
                            if (envIcon) {
                                envIcon.style.filter = 'drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.3))';
                            }
                        }, food.value);
                        break;
                    case 'speed':
                        // Temporary speed boost for player
                        const originalSpeed = gameState.envIconSpeed;
                        gameState.envIconSpeed *= 2;
                        setTimeout(() => {
                            gameState.envIconSpeed = originalSpeed;
                        }, food.value);
                        break;
                }
            }

            // Add to daily stats for good foods and bonuses
            if (food.type === 'good' || food.type === 'bonus') {
                gameState.addDailyStats(1);
            }

            updateGameUI();
            gameState.checkAchievements();
        }

        function getBonusText(bonus) {
            switch (bonus.type) {
                case 'life': return '+1 vie';
                case 'score': return `+${bonus.value} pts`;
                case 'shield': return 'Protection!';
                case 'speed': return 'Vitesse!';
                default: return '+Bonus';
            }
        }

        function foodMissed(index) {
            const food = gameState.foods[index];
            if (!food || food.caught) return;

            food.element.classList.add('missed');
            
            if (food.type === 'good') {
                // Missed good food - reset combo
                gameState.combo = 0;
                audioManager.play('miss');
                updateComboDisplay();
            } else if (food.type === 'bad') {
                // Missed bad food - bonus points for avoiding unhealthy food
                const bonus = Math.floor(food.value * 0.5);
                gameState.score += bonus;
                showScorePopup(food.x, food.y, `+${bonus} pts`, '#10b981');
            }

            if (food.type === 'good') {
                gameState.foodMissed++;
            }

            updateGameUI();
        }

        function showScorePopup(x, y, text, color = '#16a34a') {
            const popup = document.createElement('div');
            popup.textContent = text;
            popup.style.cssText = `
                position: absolute;
                left: ${x}px;
                top: ${y}px;
                color: ${color};
                font-weight: 800;
                font-size: 1rem;
                z-index: 50;
                pointer-events: none;
                animation: scorePopup 0.8s ease-out forwards;
            `;

            // Add score popup animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes scorePopup {
                    0% { opacity: 1; transform: translateY(0) scale(1); }
                    100% { opacity: 0; transform: translateY(-30px) scale(1.1); }
                }
            `;
            document.head.appendChild(style);
            document.getElementById('gameArea').appendChild(popup);

            setTimeout(() => {
                if (popup.parentNode) {
                    popup.parentNode.removeChild(popup);
                }
            }, 800);
        }

        // Game Loop
        function startGameLoop() {
            clearGameTimers();

            gameState.gameLoop = setInterval(() => {
                if (!gameState.isGameActive || gameState.isPaused) return;
                updateEnvIconPosition();
                updateFoodPositions();
                checkFoodCollisions();
            }, 16); // ~60 FPS

            gameState.foodSpawner = setTimeout(spawnFood, 1000);
        }

        function clearGameTimers() {
            if (gameState.gameLoop) {
                clearInterval(gameState.gameLoop);
                gameState.gameLoop = null;
            }
            if (gameState.foodSpawner) {
                clearTimeout(gameState.foodSpawner);
                gameState.foodSpawner = null;
            }
            if (gameState.comboTimer) {
                clearTimeout(gameState.comboTimer);
                gameState.comboTimer = null;
            }
        }

        // Level Management
        function completeLevel() {
            gameState.isGameActive = false;
            clearGameTimers();
            audioManager.play('levelComplete');

            // Calculate humanitarian impact
            const humanitarianAmount = Math.floor(gameState.foodCaught / 3);
            gameState.humanitarianSends += humanitarianAmount;
            gameState.levelsCompleted++;

            // Select random crisis region
            const crisisRegion = CRISIS_REGIONS[Math.floor(Math.random() * CRISIS_REGIONS.length)];
            const crisisRegionElement = document.getElementById('crisisRegion');
            if (crisisRegionElement) {
                crisisRegionElement.textContent = crisisRegion;
            }

            // Update UI
            const levelFoodSaved = document.getElementById('levelFoodSaved');
            const levelScore = document.getElementById('levelScore');
            const levelHumanitarian = document.getElementById('levelHumanitarian');
            const levelComboBonus = document.getElementById('levelComboBonus');
            const humanitarianAmountElement = document.getElementById('humanitarianAmount');

            if (levelFoodSaved) levelFoodSaved.textContent = gameState.foodCaught;
            if (levelScore) levelScore.textContent = gameState.score;
            if (levelHumanitarian) levelHumanitarian.textContent = humanitarianAmount;
            if (levelComboBonus) levelComboBonus.textContent = gameState.maxCombo * 50;
            if (humanitarianAmountElement) humanitarianAmountElement.textContent = humanitarianAmount;

            // Add combo bonus to score
            gameState.score += gameState.maxCombo * 50;

            // Check for perfect level (no lives lost)
            if (gameState.lives === gameState.maxLives && !gameState.unlockedAchievements.includes('perfectionist')) {
                gameState.unlockedAchievements.push('perfectionist');
                gameState.showAchievementUnlock('perfectionist');
            }

            gameState.saveStats();

            if (gameState.gameMode === 'multiplayer') {
                handleMultiplayerLevelComplete();
            } else {
                showScreen('levelCompleteScreen');
            }
        }

        function handleMultiplayerLevelComplete() {
            gameState.playerScores[gameState.currentPlayer - 1] = gameState.score;
            gameState.playerStats[gameState.currentPlayer - 1] = {
                foodCaught: gameState.foodCaught,
                level: gameState.level,
                maxCombo: gameState.maxCombo
            };

            if (gameState.currentPlayer < gameState.totalPlayers) {
                // Switch to next player
                gameState.currentPlayer++;
                showMultiplayerTurn();
            } else {
                // All players finished, show results
                showMultiplayerResults();
            }
        }

        function showMultiplayerTurn() {
            const nextPlayerNumber = document.getElementById('nextPlayerNumber');
            const scoresContainer = document.getElementById('currentScores');

            if (nextPlayerNumber) {
                nextPlayerNumber.textContent = gameState.currentPlayer;
            }

            if (scoresContainer) {
                scoresContainer.innerHTML = '';
                for (let i = 0; i < gameState.currentPlayer - 1; i++) {
                    const scoreDiv = document.createElement('div');
                    scoreDiv.className = 'player-score';
                    scoreDiv.innerHTML = `
                        <span>Joueur ${i + 1}</span>
                        <span>${gameState.playerScores[i]} points</span>
                    `;
                    scoresContainer.appendChild(scoreDiv);
                }
            }

            showScreen('multiplayerTurnScreen');
        }

        function startPlayerTurn() {
            // Reset game state for new player
            gameState.level = 1;
            gameState.score = 0;
            gameState.lives = 3;
            gameState.foodCaught = 0;
            gameState.combo = 0;
            gameState.maxCombo = 0;

            // Clear existing foods
            gameState.foods.forEach(food => {
                if (food.element.parentNode) {
                    food.element.parentNode.removeChild(food.element);
                }
            });
            gameState.foods = [];

            setupGameEnvironment();
            showScreen('gameScreen');
            startGameLoop();
        }

        function showMultiplayerResults() {
            const winner = gameState.playerScores[0] > gameState.playerScores[1] ? 1 : 2;
            const winnerScore = Math.max(...gameState.playerScores);

            // Update best score if necessary
            if (winnerScore > gameState.bestScore) {
                gameState.bestScore = winnerScore;
                const newRecordItem = document.getElementById('newRecordItem');
                if (newRecordItem) {
                    newRecordItem.style.display = 'flex';
                }
            }

            const finalScore = document.getElementById('finalScore');
            const totalFoodSavedResult = document.getElementById('totalFoodSavedResult');
            const totalHumanitarianResult = document.getElementById('totalHumanitarianResult');

            if (finalScore) finalScore.textContent = winnerScore;
            if (totalFoodSavedResult) totalFoodSavedResult.textContent = gameState.totalFoodSaved;
            if (totalHumanitarianResult) totalHumanitarianResult.textContent = gameState.humanitarianSends;

            showScreen('gameOverScreen');
            showNotification(`Joueur ${winner} gagne avec ${winnerScore} points!`, 'victory');
        }

        function nextLevel() {
            gameState.level++;
            gameState.lives = Math.min(5, 3 + Math.floor(gameState.level / 5));
            gameState.maxLives = gameState.lives;
            gameState.foodCaught = 0;
            gameState.combo = 0;
            gameState.maxCombo = 0;

            // Increase difficulty based on level and environment
            gameState.foodSpeed += 0.2 + (gameState.level - 1) * 0.1;
            
            // Calculate spawn rate with proper progression
            const baseSpawnRate = ENVIRONMENTS[gameState.environment].spawnRate;
            const difficultyFactor = 1 - (gameState.level - 1) * 0.1;
            gameState.foodSpawnRate = Math.max(600, baseSpawnRate * difficultyFactor);

            // Clear existing foods
            gameState.foods.forEach(food => {
                if (food.element.parentNode) {
                    food.element.parentNode.removeChild(food.element);
                }
            });
            gameState.foods = [];

            setupGameEnvironment();
            showScreen('gameScreen');
            startGameLoop();
        }

        function gameOver() {
            gameState.isGameActive = false;
            clearGameTimers();

            // Update best score
            if (gameState.score > gameState.bestScore) {
                gameState.bestScore = gameState.score;
                const newRecordItem = document.getElementById('newRecordItem');
                if (newRecordItem) {
                    newRecordItem.style.display = 'flex';
                }
            }

            const finalScore = document.getElementById('finalScore');
            const totalFoodSavedResult = document.getElementById('totalFoodSavedResult');
            const totalHumanitarianResult = document.getElementById('totalHumanitarianResult');

            if (finalScore) finalScore.textContent = gameState.score;
            if (totalFoodSavedResult) totalFoodSavedResult.textContent = gameState.totalFoodSaved;
            if (totalHumanitarianResult) totalHumanitarianResult.textContent = gameState.humanitarianSends;

            gameState.saveStats();
            showScreen('gameOverScreen');
        }

        function restartGame() {
            clearGameTimers();

            // Clear foods
            gameState.foods.forEach(food => {
                if (food.element.parentNode) {
                    food.element.parentNode.removeChild(food.element);
                }
            });

            if (gameState.gameMode === 'multiplayer') {
                gameState.currentPlayer = 1;
                gameState.playerScores = [0, 0];
            }

            initializeGame();
        }

        // Pause System
        function pauseGame() {
            gameState.isPaused = true;
            clearGameTimers();

            const pauseLevel = document.getElementById('pauseLevel');
            const pauseScore = document.getElementById('pauseScore');
            const pauseLives = document.getElementById('pauseLives');

            if (pauseLevel) pauseLevel.textContent = gameState.level;
            if (pauseScore) pauseScore.textContent = gameState.score;
            if (pauseLives) pauseLives.textContent = gameState.lives;

            showScreen('pauseScreen');
        }

        function resumeGame() {
            gameState.isPaused = false;
            showScreen('gameScreen');
            startGameLoop();
        }

        // Notification System
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: ${type === 'achievement' ? '#fbbf24' : type === 'victory' ? '#22c55e' : '#3b82f6'};
                color: white;
                padding: 0.75rem 1.5rem;
                border-radius: 15px;
                font-weight: 700;
                z-index: 1000;
                animation: notificationSlide 2.5s ease-out forwards;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            `;

            // Add notification animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes notificationSlide {
                    0% { opacity: 0; transform: translateX(-50%) translateY(-15px); }
                    10%, 90% { opacity: 1; transform: translateX(-50%) translateY(0); }
                    100% { opacity: 0; transform: translateX(-50%) translateY(-15px); }
                }
            `;
            document.head.appendChild(style);
            document.body.appendChild(notification);

            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 2500);
        }

        // Initialization
        document.addEventListener('DOMContentLoaded', function () {
            // Initialize controls
            initializeEnvIconControls();

            // Initialize UI
            updateStatsDisplay();

            // Handle visibility changes (pause on background)
            document.addEventListener('visibilitychange', function () {
                if (document.hidden && gameState.isGameActive && !gameState.isPaused) {
                    pauseGame();
                }
            });

            console.log('Food-H - Prêt à jouer!');
            console.log('Version: 1.0.0');
            console.log('Développé pour la lutte contre le gaspillage alimentaire');
        });

// ============================================================================
// Ajouté par Enter Africa Cameroun : délégation d'événements pour remplacer
// les attributs onclick="" inline (retirés du HTML), afin de respecter une
// Content-Security-Policy stricte sans 'unsafe-inline' sur script-src.
// ============================================================================
document.addEventListener('click', function (e) {
    var target = e.target.closest('[data-action]');
    if (!target) return;
    var action = target.getAttribute('data-action');
    var arg = target.getAttribute('data-arg');
    if (typeof window[action] === 'function') {
        if (arg !== null && arg !== undefined && arg !== '') {
            window[action](arg);
        } else {
            window[action]();
        }
    }
});
